create function f_round(_value numeric, _data date)
  returns numeric
language plpgsql
as $$
declare 
 _period_id integer;

begin
 select id from industry.period  where _data between begin_date and end_date
  into _period_id;
 if _period_id = 14 then 
   return _value;
  else
   return round(_value);
  end if;  
end;
$$;

