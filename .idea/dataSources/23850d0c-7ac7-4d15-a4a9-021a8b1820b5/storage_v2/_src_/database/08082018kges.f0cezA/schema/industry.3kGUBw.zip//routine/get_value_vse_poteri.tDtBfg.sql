create function get_value_vse_poteri(id_bill integer, id_period integer)
  returns numeric
language plpgsql
as $$
DECLARE
c_value NUMERIC;
BEGIN
SELECT SUM(vse_poteri.wnag * 1000 :: NUMERIC + vse_poteri.pottrans)::NUMERIC(24,2)
FROM industry.vse_poteri
LEFT JOIN industry.billing_point ON billing_point.id = vse_poteri.id
LEFT JOIN industry.period ON vse_poteri.period_id = period.id
WHERE billing_point.id = id_bill and period.id = id_period
INTO c_value;
 c_value := coalesce(c_value, 0);
RETURN c_value;
END;
$$;

