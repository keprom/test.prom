create view sum_poter as
  SELECT period.id, sum(((vse_poteri.wnag * (1000)::numeric) + vse_poteri.pottrans)) AS "all" FROM (industry.period LEFT JOIN industry.vse_poteri ON ((period.id = vse_poteri.period_id))) GROUP BY period.id;

