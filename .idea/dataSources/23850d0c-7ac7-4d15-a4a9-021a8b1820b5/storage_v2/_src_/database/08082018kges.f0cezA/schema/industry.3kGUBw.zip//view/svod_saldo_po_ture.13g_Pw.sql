create view svod_saldo_po_ture as
  SELECT pre_svod_saldo_po_ture.name AS ture_name, pre_svod_saldo_po_ture.period_id, sum(pre_svod_saldo_po_ture.debet_value) AS sum_debet, sum(pre_svod_saldo_po_ture.kredit_value) AS sum_kredit FROM industry.pre_svod_saldo_po_ture WHERE (NOT ((pre_svod_saldo_po_ture.debet_value = (0)::numeric) AND (pre_svod_saldo_po_ture.kredit_value = (0)::numeric))) GROUP BY pre_svod_saldo_po_ture.name, pre_svod_saldo_po_ture.period_id ORDER BY pre_svod_saldo_po_ture.name;

