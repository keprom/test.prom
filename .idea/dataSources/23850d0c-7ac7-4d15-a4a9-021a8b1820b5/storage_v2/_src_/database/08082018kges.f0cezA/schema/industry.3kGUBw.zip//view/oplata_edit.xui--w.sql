create view oplata_edit as
  SELECT oplata.id, oplata.data, oplata.value, oplata.document_number, firm.dogovor, payment_number.number FROM ((industry.oplata LEFT JOIN industry.firm ON ((oplata.firm_id = firm.id))) LEFT JOIN industry.payment_number ON ((payment_number.id = oplata.payment_number_id))) ORDER BY oplata.data;

