create function get_value_poteri_nav(id_bill integer, id_period integer)
  returns numeric
language plpgsql
as $$
DECLARE
c_value NUMERIC;
BEGIN
SELECT SUM(poteri_nav.wnag * 1000 :: NUMERIC +poteri_nav.pottrans)::NUMERIC(24,2)
FROM industry.poteri_nav
LEFT JOIN industry.billing_point ON billing_point.id = poteri_nav.bill_id
LEFT JOIN industry.period ON poteri_nav.period_id = period.id
WHERE billing_point.id = id_bill and period.id = id_period
INTO c_value;
 c_value := coalesce(c_value, 0);
RETURN c_value;
END;
$$;

