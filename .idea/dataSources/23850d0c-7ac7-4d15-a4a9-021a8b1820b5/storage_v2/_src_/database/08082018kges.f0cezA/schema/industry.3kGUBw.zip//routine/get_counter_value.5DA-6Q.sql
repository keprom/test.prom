create function get_counter_value(id_bill integer, id_period integer)
  returns numeric
language plpgsql
as $$
DECLARE
c_value NUMERIC;
BEGIN
SELECT SUM(counter_value.diff * counter.transform :: NUMERIC)
FROM industry.billing_point
LEFT JOIN industry.counter ON billing_point.id = counter.point_id
LEFT JOIN industry.values_set ON counter.id = values_set.counter_id
LEFT JOIN industry.counter_value ON values_set.id = counter_value.values_set_id
LEFT JOIN industry.period ON counter_value.data >= period.begin_date AND counter_value.data <= period.end_date
WHERE billing_point.id = id_bill and period.id = id_period
INTO c_value;
c_value := coalesce(c_value, 0);
 RETURN c_value;
END;
$$;

