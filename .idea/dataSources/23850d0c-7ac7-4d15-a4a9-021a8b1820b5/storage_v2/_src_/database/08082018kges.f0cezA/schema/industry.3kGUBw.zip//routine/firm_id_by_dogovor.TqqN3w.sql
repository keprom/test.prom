create function firm_id_by_dogovor(_dogovor integer)
  returns integer
language plpgsql
as $$
declare 
 _firm_id integer;
begin
 select  id from industry.firm where dogovor=_dogovor into _firm_id;
 return _firm_id;
end;
$$;

