create function counter_type_by_name(_type_name character varying)
  returns integer
language plpgsql
as $$
declare _type_id integer;
begin
 select id from industry.counter_type where upper(name) = _type_name into _type_id;
 return _type_id;
end;
$$;

