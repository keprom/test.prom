create function open_firm(_firm_id integer)
  returns void
language plpgsql
as $$
begin
 delete from industry.firm_close where 
  firm_id=_firm_id and period_id in 
  (select value from industry.sprav 
  where name='current_period');
end;
$$;

