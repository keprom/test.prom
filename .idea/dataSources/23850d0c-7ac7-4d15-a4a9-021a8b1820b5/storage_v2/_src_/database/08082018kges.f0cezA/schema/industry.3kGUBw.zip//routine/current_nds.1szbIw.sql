create function current_nds()
  returns numeric
language plpgsql
as $$
declare 
 _nds numeric;
begin
 select nds from industry.period where id in (select sprav.value from industry.sprav where name='current_period') into _nds;
 return _nds;
end;
$$;

