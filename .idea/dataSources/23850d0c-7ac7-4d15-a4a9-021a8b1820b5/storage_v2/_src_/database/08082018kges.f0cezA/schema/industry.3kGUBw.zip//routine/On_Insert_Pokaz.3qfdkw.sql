create function "On_Insert_Pokaz"()
  returns trigger
language plpgsql
as $$
declare 
 cmd text;
 buf_val numeric(24,4);
 buf_dif numeric(24,4);
 buf_dif_tariff numeric(24,4);
 buf_data date;
 razryadnost numeric(24,0);
 _val numeric(24,4);
 date_start date;
 date_finish date;
 buf_id integer;
 tariff_id integer;
 _tariff_value numeric(24,4);
 _start date;
 _end date;
 end_tr boolean;
begin

 select begin_date,end_date from industry.period
right join industry.sprav on sprav.name='current_period' and sprav.value=period.id
into _start,_end;
if (NEW.data>_end) or (NEW.data<_start) then 
raise exception 'vyhod iz diapazona % % %',NEW.data,_start,_end; 
end if;


-- ПОЛУЧАЕМ ДАННЫЕ О СЧЕТЧИКЕ
select digit_count,data_start,data_finish,values_set.tariff_id from industry.counter
	        left join industry.values_set on counter.id=values_set.counter_id
	        where values_set.id=NEW.values_set_id 
	  into razryadnost,date_start,date_finish,tariff_id;

if date_start>NEW.data then return NULL; end if;


-- ФИЛЬТРУЕМ ПО РАЗРЯДНОСТИ
if razryadnost>20 or razryadnost<4 then  raise exception 'neprav razryad'; return NULL; end if;

if date_finish is not NULL then   return NULL; end if;
--- Вытаскиваем дату, и значение последних показаний по этой точке учета
 select value,data from industry.counter_value 
   where values_set_id = NEW.values_set_id 
    and data=(
               select MAX(data) from industry.counter_value 
                 where values_set_id=NEW.values_set_id and data<NEW.data
               )
 into buf_val,buf_data ;
 
 razryadnost:=pow(10,razryadnost);
 
 if NEW.value>=razryadnost then   return NULL; end if;

 
--- ВЫТАСКИВАЕМ РАЗНИЦУ МЕЖДУ ПОКАЗАНИЯМИ
--- ЕСЛИ ЗНАЧЕНИЕ ПОКАЗАНИЯ И ДАТА НЕ НУЛЬ И ТОГДА 
if ((buf_val  is not   null) and (buf_data is not null)) then

     --- Иначе если показания и даты разные	     
     --- ВЫЧИСЛЯЕМ РАЗНИЦУ МЕЖДУ ПОКАЗАНИЯМИ ( С УЧЕТОМ ПРОКРУТКИ )
     if buf_val>NEW.value then
	buf_dif:=razryadnost+new.value-buf_val;	        
     else 
       buf_dif:=buf_val-new.value;
     end if;
      buf_dif_tariff=buf_dif*30.0/(NEW.data-buf_data);
else 
   --- ЕСЛИ ЗНАЧЕНИЙ НЕ ВЫТАЩЕНО ( ЗНАЧИТ ЭТО ПОКАЗАНИЯ УСТАНОВКИ СЧЕТЧИКА )
   buf_dif:=0;
   buf_dif_tariff:=0;
end if;
   --- ВЫТАЩЕНА РАЗНИЦА МЕЖДУ ПОКАЗАНИЯМИ И СОХРАНЕНА В ПЕРЕМЕННОЙ BUF_DIF
   --- ДАЛЕЕ НЕОБХОДИМО ВЫТАЩИТЬ ЗНАЧЕНИЕ ТАРИФА
buf_dif=abs(buf_dif);
buf_dif_tariff=abs(buf_dif_tariff); 


if (tariff_id<>12) then

select industry.tariff_by_data_kvt_tariffid(new.data,buf_dif_tariff,tariff_id) into _tariff_value;
if buf_dif=0 then _tariff_value=0; end if;
if _tariff_value is null then 
raise exception 'problemmy s tariffom';
return NULL;
end if;
NEW.diff=buf_dif;
NEW.tariff_value=_tariff_value;


-- ИЗМЕНЯЕМ КОЛИЧЕСТВО НАМОТАННЫХ КИЛОВАТ НА СЛЕДУЮЩИХ ПОКАЗАНИЯХ ЕСЛИ ОНИ СУЩЕСТВУЮТ...
 select value,data,id from industry.counter_value 
   where values_set_id = NEW.values_set_id 
    and data=(
               select MIN(data) from industry.counter_value 
                 where values_set_id=NEW.values_set_id and data>NEW.data
               )
 into buf_val,buf_data,buf_id ;

if buf_id is not null then
 if NEW.value>buf_val then
	  buf_dif:=razryadnost+buf_val-new.value;	        
	else 
	  buf_dif:=new.value-buf_val;
	end if;
        buf_dif_tariff=buf_dif*30.0/(buf_data-NEW.data);
        buf_dif=abs(buf_dif);
	buf_dif_tariff=abs(buf_dif_tariff);

	select industry.tariff_by_data_kvt_tariffid(buf_data,buf_dif_tariff,tariff_id) into _tariff_value;

	if _tariff_value is null then 
	 raise exception 'problemy s rascetom tariffa--';
	 return NULL;
	end if;
	update industry.counter_value set diff=buf_dif,tariff_value=_tariff_value where id=buf_id;
end if;

select nds from industry.period where begin_date<=NEW.data and end_date>=NEW.data into NEW.nds;

else

if (new.uroven = 0) then
end_tr = industry.pokazaniya_drob(new.value, new.values_set_id, new.data, buf_dif, new.uroven, buf_val);
if (end_tr = true) then
return null;
else
raise exception 'oshibka pri droblenii';
return null;
end if;







end if;
end if;
return NEW;
end;
$$;

