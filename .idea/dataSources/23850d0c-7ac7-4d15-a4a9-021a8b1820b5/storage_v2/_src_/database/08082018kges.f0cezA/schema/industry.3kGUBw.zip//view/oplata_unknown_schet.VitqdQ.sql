create view oplata_unknown_schet as
  SELECT DISTINCT oplata_buf.schet FROM industry.oplata_buf WHERE (NOT (btrim((oplata_buf.schet)::text) IN (SELECT btrim((payment_number.number)::text) AS btrim FROM industry.payment_number))) ORDER BY oplata_buf.schet;

