create view analiz_po_tp as
  SELECT ture.id AS ture_id, tp.name AS tp_name, sum(vedomost.itogo_kvt) AS kvt, period.id AS period_id FROM ((((industry.ture LEFT JOIN industry.period ON ((1 = 1))) LEFT JOIN industry.tp ON ((ture.id = tp.ture_id))) LEFT JOIN industry.billing_point ON ((tp.id = billing_point.tp_id))) LEFT JOIN industry."vedomost-2numround" vedomost ON (((billing_point.id = vedomost.bill_id) AND (period.id = vedomost.period_id)))) GROUP BY ture.id, tp.name, period.id;

