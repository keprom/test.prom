create view period_years as
  SELECT DISTINCT date_part('year'::text, period.begin_date) AS period_year FROM industry.period ORDER BY date_part('year'::text, period.begin_date) DESC;

