create view "нулевики" as
  SELECT firm.name, vedomost.period_id, billing_point.name AS point_name, sum(vedomost.itogo_tenge) AS sum FROM ((industry.firm LEFT JOIN industry.billing_point ON ((firm.id = billing_point.firm_id))) LEFT JOIN industry."vedomost-2numround" vedomost ON ((vedomost.bill_id = billing_point.id))) WHERE (vedomost.period_id = 20) GROUP BY firm.id, firm.name, vedomost.period_id, billing_point.name ORDER BY firm.id;

