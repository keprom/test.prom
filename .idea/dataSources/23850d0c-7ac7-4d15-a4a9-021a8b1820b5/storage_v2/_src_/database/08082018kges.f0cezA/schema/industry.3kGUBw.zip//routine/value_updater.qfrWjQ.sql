create function value_updater(_values_set_id integer, _new_value numeric)
  returns numeric
language plpgsql
as $$
declare 
  _value numeric;
  _value_diff numeric;
begin
 select max(value) from industry.counter_value where values_set_id=_values_set_id and data=(select max(data) from industry.counter_value where values_set_id=_values_set_id) limit 1 into _value;
 _value_diff = _new_value - _value;
 update industry.counter_value set "value"="value" + _value_diff where values_set_id = _values_set_id;
 
 select min(value) from industry.counter_value where values_set_id=_values_set_id and data=(select min(data) from industry.counter_value where values_set_id=_values_set_id) limit 1 into _value;
return _value;
end;
$$;

