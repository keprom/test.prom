create view with_poteri as
  SELECT firm_with_poter.firm_id AS id, firm.dogovor, firm.name FROM (industry.firm_with_poter LEFT JOIN industry.firm ON (((firm.id = firm_with_poter.firm_id) AND (firm.firm_closed = false))));

