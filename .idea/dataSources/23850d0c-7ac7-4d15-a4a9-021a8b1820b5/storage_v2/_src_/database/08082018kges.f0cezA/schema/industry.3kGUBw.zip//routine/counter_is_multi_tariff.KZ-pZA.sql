create function counter_is_multi_tariff(_counter_id integer)
  returns boolean
language plpgsql
as $$
declare 
   _count integer;
begin
  select count(*) from industry.values_set where counter_id=_counter_id and tariff_id in (2,3,7,8,9) 
    into _count;
  if (_count>0) then return true; else return false; end if;
end;
$$;

