create view list_of_firms as
  SELECT firm.dogovor, firm.name AS firm_name, firm.user_id, firm.address AS firm_address, firm.telefon, firm.dogovor_date, ture.id AS ture_id, ture.name AS ture_name, firm_subgroup.name AS firm_subgroup_name FROM ((industry.firm LEFT JOIN industry.firm_subgroup ON ((firm.subgroup_id = firm_subgroup.id))) LEFT JOIN industry.ture ON ((ture.id = firm.ture_id))) GROUP BY firm.subgroup_id, firm.dogovor, firm.name, firm.address, firm.telefon, firm.dogovor_date, ture.id, ture.name, firm_subgroup.name, firm.user_id ORDER BY firm.subgroup_id, firm.dogovor;

