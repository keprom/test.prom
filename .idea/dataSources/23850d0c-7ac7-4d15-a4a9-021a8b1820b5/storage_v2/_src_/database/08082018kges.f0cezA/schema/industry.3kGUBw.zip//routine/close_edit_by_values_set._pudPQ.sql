create function close_edit_by_values_set()
  returns trigger
language plpgsql
as $$
declare
	_firm_id integer;
	_billing_point_id integer;
	_counter_id integer;
	_period_id integer;
	_error integer;
	_current_period integer;
begin
	
	if (TG_OP='INSERT') or (TG_OP='UPDATE') then
		select counter_id  from industry.values_set 
		where  id=NEW.values_set_id  into _counter_id;
	end if;

	if TG_OP='DELETE' then
		select counter_id  from industry.values_set 
		where  id=OLD.values_set_id  into _counter_id;
	end if;
	
	select point_id from industry.counter
		where id=_counter_id into _billing_point_id;

	select firm_id from industry.billing_point
	where  id=_billing_point_id into _firm_id;

	select value::integer from industry.sprav where name='current_period' into _current_period;

	select id from industry.firm_close 
	where period_id=_current_period and firm_id=_firm_id
	into _error;

	if _error is not null then 
		raise exception 'firm closed';
	end if;
	if (TG_OP='INSERT') or (TG_OP='UPDATE') then
		return NEW;
	end if;
	if TG_OP='DELETE' then
		return OLD;
	end if;
	
end;
$$;

