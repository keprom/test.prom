create function get_days_count(input_date date)
  returns integer
language plpgsql
as $$
declare count_days INTEGER;
begin
SELECT DATE_PART('days', DATE_TRUNC('month', input_date) + '1 MONTH'::INTERVAL - '1 DAY'::INTERVAL) into count_days;
return count_days;
end;
$$;

