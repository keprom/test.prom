create view not_current_counter_value as
  SELECT counter.id AS counter_id, counter_value.value, counter_value.diff, counter_value.data FROM ((((industry.counter LEFT JOIN industry.values_set ON ((counter.id = values_set.counter_id))) LEFT JOIN industry.counter_value ON ((values_set.id = counter_value.values_set_id))) LEFT JOIN industry.sprav ON (((sprav.name)::text = 'current_period'::text))) LEFT JOIN industry.period ON (((sprav.value)::integer = period.id))) WHERE ((counter_value.data < period.begin_date) OR (counter_value.data > period.end_date));

comment on view not_current_counter_value
is 'Необходимы для возможности определения возможности удаления счетчика. Если у счетчика имеются показания вне этого периода значит счетчик удалить нельзя ибо изменится начисление за прошлый период';

