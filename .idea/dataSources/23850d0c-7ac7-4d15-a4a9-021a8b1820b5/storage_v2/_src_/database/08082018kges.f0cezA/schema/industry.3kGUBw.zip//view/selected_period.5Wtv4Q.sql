create view selected_period as
  SELECT period.id, period.begin_date, period.end_date, period.name, period.nds, CASE WHEN (ch.value IS NOT NULL) THEN 'selected'::text ELSE ''::text END AS checked FROM ((industry.period JOIN industry.sprav ON ((((period.id)::numeric <= sprav.value) AND ((sprav.name)::text = 'current_period'::text)))) LEFT JOIN industry.sprav ch ON ((((period.id)::numeric = ch.value) AND ((ch.name)::text = 'current_period'::text)))) ORDER BY period.end_date DESC LIMIT 24;

