create function my_round(value numeric)
  returns numeric
language plpgsql
as $$
begin
return trunc(value*100)/100;
end;

$$;

