create view fine_firm_oplata_itog as
  SELECT fine_oplata.firm_id, (sum((round((fine_oplata.value * ((100)::numeric + fine_oplata.nds))) / (100)::numeric)))::numeric(24,2) AS fine_oplata_value, fine_oplata.nds, period.id AS period_id FROM (industry.fine_oplata LEFT JOIN industry.period ON (((fine_oplata.data >= period.begin_date) AND (fine_oplata.data <= period.end_date)))) GROUP BY fine_oplata.firm_id, fine_oplata.nds, period.id;

