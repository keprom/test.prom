create view fine_2_re_ture as
  SELECT period.id AS period_id, firm_subgroup.id AS firm_subgroup_id, firm_subgroup.name AS firm_subgroup_name, fine_7_re.ture_id, sum(fine_7_re.debet_start) AS sum_debet_start, sum(fine_7_re.kredit_start) AS sum_kredit_start, sum(fine_7_re.nachisleno) AS sum_nachisleno, sum(fine_7_re.oplata) AS sum_oplata, sum(fine_7_re.debet_end) AS sum_debet_end, sum(fine_7_re.kredit_end) AS sum_kredit_end FROM ((industry.fine_7_re JOIN industry.period ON ((fine_7_re.period_id = period.id))) JOIN industry.firm_subgroup ON ((firm_subgroup.id = fine_7_re.firm_subgroup_id))) GROUP BY period.id, firm_subgroup.id, firm_subgroup.name, fine_7_re.ture_id;

comment on view fine_2_re_ture
is 'ПЕНЯ. 2-РЭ по ТУРЭ';

