create function last_counter_value_data(_values_set_id integer, _data date)
  returns date
language plpgsql
as $$
declare 
  _data_result date;
begin
 select data from industry.counter_value where values_set_id=_values_set_id and data<_data order by data desc limit 1 into _data_result;
return _data_result;
end;
$$;

