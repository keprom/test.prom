create function is_closed(_firm_id integer)
  returns boolean
language plpgsql
as $$
declare _count integer;
begin
 select count(firm_close.id) from industry.firm_close,industry.sprav where  
 sprav.name='current_period' and firm_id=_firm_id and firm_close.period_id=sprav.value::integer
   into _count;
   if _count>0 then return true;
   else 
     return false;
   end if;  
end;
$$;

