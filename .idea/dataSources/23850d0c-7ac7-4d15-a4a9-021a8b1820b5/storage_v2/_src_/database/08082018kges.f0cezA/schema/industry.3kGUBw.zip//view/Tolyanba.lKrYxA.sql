create view "Tolyanba" as
  SELECT firm.id AS frim_id, firm.dogovor AS firm_dog FROM industry.firm;

