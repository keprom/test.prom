create view firm_with_poter as
  SELECT firm.id AS firm_id, billing_point.id AS bill_id, firm.period_id, period.begin_date, period.end_date FROM ((industry.firm LEFT JOIN industry.period ON ((period.id = firm.period_id))) LEFT JOIN industry.billing_point ON ((firm.id = billing_point.firm_id))) WHERE (((firm.is_pot_id)::text <> 'false'::text) AND ((firm.is_pot_id)::text <> '2'::text));

