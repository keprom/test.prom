create view aston23 as
  SELECT a1.billing_id AS bill_id, sum(a1.nadbavka) AS nadbavka, sum(a1.kvt) AS kvt, a1.period_id, obwii.value, period.end_date, period.id AS period_idiwka FROM ((industry.a12 a1 LEFT JOIN industry.obwii ON ((obwii.data = (SELECT max(obwii.data) AS max FROM industry.obwii WHERE (obwii.data <= a1.counter_value_data))))) LEFT JOIN industry.period ON (((a1.counter_value_data <= period.end_date) AND (a1.counter_value_data >= period.begin_date)))) GROUP BY a1.billing_id, a1.period_id, obwii.value, period.end_date, period.id;

