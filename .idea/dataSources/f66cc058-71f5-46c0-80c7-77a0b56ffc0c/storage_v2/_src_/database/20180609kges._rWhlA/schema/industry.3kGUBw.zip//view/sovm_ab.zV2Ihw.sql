create view sovm_ab as
  SELECT sovm_absolutnyy.id, sovm_absolutnyy.parent_firm_id, sovm_absolutnyy.value, sovm_absolutnyy.data, sovm_absolutnyy.values_set_id, sovm_absolutnyy.tariff_value, firm.name AS firm_name FROM (industry.sovm_absolutnyy LEFT JOIN industry.firm ON ((sovm_absolutnyy.parent_firm_id = firm.id)));

