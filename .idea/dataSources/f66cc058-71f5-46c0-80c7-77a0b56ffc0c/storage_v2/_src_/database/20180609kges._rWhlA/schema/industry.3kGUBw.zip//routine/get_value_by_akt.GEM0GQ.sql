create function get_value_by_akt(id_bill integer, id_period integer)
  returns numeric
language plpgsql
as $$
DECLARE
c_value NUMERIC;
BEGIN
SELECT SUM(akt.value)::NUMERIC(24,2)
FROM industry.akt
LEFT JOIN industry.values_set ON values_set.id = akt.values_set_id
LEFT JOIN industry.counter ON values_set.counter_id = counter.id
LEFT JOIN industry.billing_point ON billing_point.id = counter.point_id
LEFT JOIN industry.period ON akt.data >= period.begin_date AND akt.data <= period.end_date
WHERE billing_point.id = id_bill and period.id = id_period
INTO c_value;
 c_value := coalesce(c_value, 0);
RETURN c_value;
END;
$$;

