create view current_ot_nadbavka as
  SELECT nadbavka_otnositelnaya.id, nadbavka_otnositelnaya.value, nadbavka_otnositelnaya.billing_point_id, nadbavka_otnositelnaya.period_id FROM (industry.nadbavka_otnositelnaya LEFT JOIN industry.sprav ON (((sprav.name)::text = 'current_period'::text))) WHERE (nadbavka_otnositelnaya.period_id = (sprav.value)::integer);

