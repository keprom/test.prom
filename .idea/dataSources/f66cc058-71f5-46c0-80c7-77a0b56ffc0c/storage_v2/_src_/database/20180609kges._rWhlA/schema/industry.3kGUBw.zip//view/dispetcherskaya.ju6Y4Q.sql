create view dispetcherskaya as
  SELECT tp.name AS tp, firm.name, firm.telefon, firm.id FROM ((industry.billing_point LEFT JOIN industry.firm ON ((firm.id = billing_point.firm_id))) LEFT JOIN industry.tp ON ((tp.id = billing_point.tp_id))) ORDER BY tp.name, firm.name;

