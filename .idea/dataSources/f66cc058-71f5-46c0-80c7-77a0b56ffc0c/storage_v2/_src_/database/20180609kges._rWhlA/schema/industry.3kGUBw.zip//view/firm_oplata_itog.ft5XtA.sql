create view firm_oplata_itog as
  SELECT oplata.firm_id, (sum((round((oplata.value * ((100)::numeric + oplata.nds))) / (100)::numeric)))::numeric(24,2) AS oplata_value, oplata.nds, period.id AS period_id FROM (industry.oplata LEFT JOIN industry.period ON (((oplata.data >= period.begin_date) AND (oplata.data <= period.end_date)))) GROUP BY oplata.firm_id, oplata.nds, period.id;

