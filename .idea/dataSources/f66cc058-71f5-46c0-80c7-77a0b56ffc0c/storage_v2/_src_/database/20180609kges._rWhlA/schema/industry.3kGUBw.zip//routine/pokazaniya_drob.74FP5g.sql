create function pokazaniya_drob(_value numeric, _values_set_id integer, _data date, _kvt numeric, _uroven integer, _pre_pokaz numeric, OUT ind boolean)
  returns boolean
language plpgsql
as $$
declare

tar numeric(24,4);
_nds numeric(24,4);
_nadbavka_ur  numeric(24,4);
_nadbavka_ost  numeric(24,4);
_person numeric(24,4);
_start_data date;
_end_data date;
_last_kvt numeric(24,4);
_last_uroven numeric(24,4);
_last_trans numeric(24,4);
_firm integer;
razryadnost integer;
_trans numeric(24,4);
begin




-- ПОЛУЧАЕМ ДАННЫЕ О СЧЕТЧИКЕ
select digit_count from industry.counter
	        left join industry.values_set on counter.id=values_set.counter_id
	        where values_set.id=_values_set_id 
	  into razryadnost;

-- ФИЛЬТРУЕМ ПО РАЗРЯДНОСТИ
 
 razryadnost:=pow(10,razryadnost);


ind = false;

select counter.transform from industry.values_set
	left join industry.counter on counter.id = values_set.counter_id
	where values_set.id = _values_set_id
into _trans;


select firm.person, firm.id from industry.firm
left join industry.billing_point on billing_point.firm_id = firm.id
left join industry.counter on counter.point_id = billing_point.id
left join industry.values_set on values_set.counter_id = counter.id
where values_set.id = _values_set_id
into _person, _firm;


select begin_date, end_date from industry.period
	where id = (select "value" from industry.sprav where "name" = 'current_period')
	into _start_data, _end_data;

select nds from industry.period where begin_date<=_data and end_date>=_data into _nds;


select sum(nadbavka_absolutnaya.value), nadbavka_absolutnaya.uroven
	from industry.nadbavka_absolutnaya
	left join industry.values_set on values_set.id = nadbavka_absolutnaya.values_set_id
	left join industry.counter on counter.id = values_set.counter_id
	left join industry.billing_point on billing_point.id = counter.point_id
	left join industry.firm on firm.id = billing_point.firm_id
	where firm.id = _firm 
		and values_set.tariff_id = 12
		and nadbavka_absolutnaya.data >= _start_data
		and nadbavka_absolutnaya.data <= _end_data
		and nadbavka_absolutnaya.uroven = (select max(uroven)
						from industry.nadbavka_absolutnaya
							left join industry.values_set on values_set.id = nadbavka_absolutnaya.values_set_id
							left join industry.counter on counter.id = values_set.counter_id
							left join industry.billing_point on billing_point.id = counter.point_id
							left join industry.firm on firm.id = billing_point.firm_id
							where firm.id = _firm 
								and values_set.tariff_id = 12
								and nadbavka_absolutnaya.data >= _start_data
								and nadbavka_absolutnaya.data <= _end_data)
group by nadbavka_absolutnaya.uroven
into _nadbavka_ost, _nadbavka_ur;


select sum(counter_value.diff*counter.transform), counter_value.uroven
	from industry.counter_value
	left join industry.values_set on values_set.id = counter_value.values_set_id
	left join industry.counter on counter.id = values_set.counter_id
	left join industry.billing_point on billing_point.id = counter.point_id
	left join industry.firm on firm.id = billing_point.firm_id
	where firm.id = _firm 
		and values_set.tariff_id = 12
		and counter_value.data >= _start_data
		and counter_value.data <= _end_data
		and counter_value.uroven = (select max(counter_value.uroven)
						from industry.counter_value
							left join industry.values_set on values_set.id = counter_value.values_set_id
							left join industry.counter on counter.id = values_set.counter_id
							left join industry.billing_point on billing_point.id = counter.point_id
							left join industry.firm on firm.id = billing_point.firm_id
							where firm.id = _firm 
								and values_set.tariff_id = 12
								and counter_value.data >= _start_data
								and counter_value.data <= _end_data)
group by counter_value.uroven
into _last_kvt, _last_uroven;





if (_last_uroven is null) then

if (_nadbavka_ur is null) then

   
	if (_uroven=0) then 

		if (_kvt*_trans <= 100*_person) then

			tar = industry.uroven_tariff_value(_data,100,12);
			insert into industry.counter_value ("values_set_id", "value", "data", "diff", "tariff_value", "nds", "uroven") 
			values (_values_set_id, _value, _data, _kvt, tar, _nds, 1);
			ind = true;
		end if;


		if (_kvt*_trans > 100*_person) and (_kvt*_trans <= 190*_person) then
		        if (_pre_pokaz+(100/_trans)*_person>=razryadnost) then _pre_pokaz=_pre_pokaz-razryadnost;
		        end if;
			tar = industry.uroven_tariff_value(_data,100,12);
			insert into industry.counter_value ("values_set_id", "value", "data", "diff", "tariff_value", "nds", "uroven") 
			values (_values_set_id, _pre_pokaz+(100/_trans)*_person, _data, (100/_trans)*_person, tar, _nds, 1);	

			tar = industry.uroven_tariff_value(_data,90,12);
		
			insert into industry.counter_value ("values_set_id", "value", "data", "diff", "tariff_value", "nds", "uroven") 
			values (_values_set_id, _value, _data+1, _kvt - (100/_trans)*_person, tar, _nds, 2);
			ind = true;
		end if;

		if (_kvt*_trans > 190*_person) then
			if (_pre_pokaz+(100/_trans)*_person>=razryadnost) then _pre_pokaz=_pre_pokaz-razryadnost;
		        end if;
			tar = industry.uroven_tariff_value(_data,100,12);
			insert into industry.counter_value ("values_set_id", "value", "data", "diff", "tariff_value", "nds", "uroven") 
			values (_values_set_id, _pre_pokaz+(100/_trans)*_person, _data, (100/_trans)*_person, tar, _nds, 1);
			if (_pre_pokaz+(190/_trans)*_person>=razryadnost) then _pre_pokaz=_pre_pokaz-razryadnost;
		        end if;
			tar = industry.uroven_tariff_value(_data,90,12);
			insert into industry.counter_value ("values_set_id", "value", "data", "diff", "tariff_value", "nds", "uroven") 
			values (_values_set_id, _pre_pokaz+(190/_trans)*_person, _data+1, (90/_trans)*_person, tar, _nds, 2);

			tar = industry.uroven_tariff_value(_data,200,12);
		
			insert into industry.counter_value ("values_set_id", "value", "data", "diff", "tariff_value", "nds", "uroven") 
			values (_values_set_id, _value, _data+2, _kvt - (190/_trans)*_person, tar, _nds, 3);
			ind = true;
		end if;




	end if;
else

	if (_uroven=0) then 

		if (_nadbavka_ur = 3) then
			tar = industry.uroven_tariff_value(_data,200,12);
			insert into industry.counter_value ("values_set_id", "value", "data", "diff", "tariff_value", "nds", "uroven") 
			values (_values_set_id, _value, _data, _kvt, tar, _nds, 3);
			ind = true;
		end if;


		if (_nadbavka_ur = 2) then

			if (((_kvt*_trans)+_nadbavka_ost)>90*_person) then
			if (_pre_pokaz+(90/_trans)*_person- (_nadbavka_ost/_trans)>=razryadnost) then _pre_pokaz=_pre_pokaz-razryadnost;
		        end if;
				tar = industry.uroven_tariff_value(_data,90,12);
				insert into industry.counter_value ("values_set_id", "value", "data", "diff", "tariff_value", "nds", "uroven") 
				values (_values_set_id, _pre_pokaz+(90/_trans)*_person- (_nadbavka_ost/_trans), _data, (90/_trans)*_person- (_nadbavka_ost/_trans), tar, _nds, 2);	

				tar = industry.uroven_tariff_value(_data,200,12);
			
				insert into industry.counter_value ("values_set_id", "value", "data", "diff", "tariff_value", "nds", "uroven") 
				values (_values_set_id, _value, _data+1, _kvt -(90/_trans)*_person+ (_nadbavka_ost/_trans), tar, _nds, 3);
				ind = true;
			else	 
	
				tar = industry.uroven_tariff_value(_data,90,12);
		
				insert into industry.counter_value ("values_set_id", "value", "data", "diff", "tariff_value", "nds", "uroven") 
				values (_values_set_id, _value, _data, _kvt, tar, _nds, 2);
				ind = true;
			end if;
		end if;

		if (_nadbavka_ur = 1) then

			if (((_kvt*_trans)+_nadbavka_ost)>190*_person) then
			if (_pre_pokaz+(100/_trans)*_person-(_nadbavka_ost/_trans)>=razryadnost) then _pre_pokaz=_pre_pokaz-razryadnost;
		        end if;
				tar = industry.uroven_tariff_value(_data,100,12);
				insert into industry.counter_value ("values_set_id", "value", "data", "diff", "tariff_value", "nds", "uroven") 
				values (_values_set_id, _pre_pokaz+(100/_trans)*_person-(_nadbavka_ost/_trans), _data, (100/_trans)*_person-(_nadbavka_ost/_trans), tar, _nds, 1);
			if (_pre_pokaz+(190/_trans)*_person-(_nadbavka_ost/_trans)>=razryadnost) then _pre_pokaz=_pre_pokaz-razryadnost;
		        end if;	
				tar = industry.uroven_tariff_value(_data,90,12);
				insert into industry.counter_value ("values_set_id", "value", "data", "diff", "tariff_value", "nds", "uroven") 
				values (_values_set_id, _pre_pokaz+(190/_trans)*_person-(_nadbavka_ost/_trans), _data+1, (90/_trans)*_person, tar, _nds, 2);

				tar = industry.uroven_tariff_value(_data,200,12);
		
				insert into industry.counter_value ("values_set_id", "value", "data", "diff", "tariff_value", "nds", "uroven") 
				values (_values_set_id, _value, _data+2, _kvt - ((190/_trans)*_person-(_nadbavka_ost/_trans)), tar, _nds, 3);
				ind = true; 
		
			end if;

			if (((_kvt*_trans)+_nadbavka_ost)>100*_person) and (((_kvt*_trans)+_nadbavka_ost)<=190*_person) then
			if (_pre_pokaz+(100/_trans)*_person-(_nadbavka_ost/_trans)>=razryadnost) then _pre_pokaz=_pre_pokaz-razryadnost;
		        end if;		
				tar = industry.uroven_tariff_value(_data,100,12);
				insert into industry.counter_value ("values_set_id", "value", "data", "diff", "tariff_value", "nds", "uroven") 
				values (_values_set_id, _pre_pokaz+(100/_trans)*_person-(_nadbavka_ost/_trans), _data, (100/_trans)*_person-(_nadbavka_ost/_trans), tar, _nds, 1);

				tar = industry.uroven_tariff_value(_data,90,12);
	
				insert into industry.counter_value ("values_set_id", "value", "data", "diff", "tariff_value", "nds", "uroven") 
				values (_values_set_id, _value, _data+1, _kvt - (100/_trans)*_person+(_nadbavka_ost/_trans), tar, _nds, 2);
				ind = true; 
			end if;

			if (((_kvt*_trans)+_nadbavka_ost)<=100*_person) then

				tar = industry.uroven_tariff_value(_data,100,12);
				insert into industry.counter_value ("values_set_id", "value", "data", "diff", "tariff_value", "nds", "uroven") 
				values (_values_set_id, _value, _data, _kvt, tar, _nds, 1);
		
				ind = true; 
			end if;
	
		end if;


	end if;
end if;

else



if (_nadbavka_ur is null) then


	if (_uroven=0) then 
	if (_last_uroven = 1) then

		if ((_kvt*_trans)+_last_kvt <= 100*_person) then
			tar = industry.uroven_tariff_value(_data,100,12);
			insert into industry.counter_value ("values_set_id", "value", "data", "diff", "tariff_value", "nds", "uroven") 
			values (_values_set_id, _value, _data, _kvt, tar, _nds, 1);
			ind = true;
		end if;


		if ((_kvt*_trans)+_last_kvt > 100*_person) and ((_kvt*_trans)+_last_kvt <= 190*_person) then
			if (_pre_pokaz+(100/_trans)*_person-(_last_kvt/_trans)>=razryadnost) then _pre_pokaz=_pre_pokaz-razryadnost;
		        end if;
			tar = industry.uroven_tariff_value(_data,100,12);
			insert into industry.counter_value ("values_set_id", "value", "data", "diff", "tariff_value", "nds", "uroven") 
			values (_values_set_id, _pre_pokaz+(100/_trans)*_person-(_last_kvt/_trans), _data, (100/_trans)*_person-(_last_kvt/_trans), tar, _nds, 1);	

			tar = industry.uroven_tariff_value(_data,90,12);
		
			insert into industry.counter_value ("values_set_id", "value", "data", "diff", "tariff_value", "nds", "uroven") 
			values (_values_set_id, _value, _data+1, _kvt - (100/_trans)*_person+(_last_kvt/_trans), tar, _nds, 2);
			ind = true;
		end if;

		if ((_kvt*_trans)+_last_kvt > 190*_person) then
if (_pre_pokaz+(100/_trans)*_person-(_last_kvt/_trans)>=razryadnost) then _pre_pokaz=_pre_pokaz-razryadnost;
		        end if;		
			tar = industry.uroven_tariff_value(_data,100,12);
			insert into industry.counter_value ("values_set_id", "value", "data", "diff", "tariff_value", "nds", "uroven") 
			values (_values_set_id, _pre_pokaz+(100/_trans)*_person-(_last_kvt/_trans), _data, (100/_trans)*_person-(_last_kvt/_trans), tar, _nds, 1);
if (_pre_pokaz+(190/_trans)*_person-(_last_kvt/_trans)>=razryadnost) then _pre_pokaz=_pre_pokaz-razryadnost;
		        end if;
			tar = industry.uroven_tariff_value(_data,90,12);
			insert into industry.counter_value ("values_set_id", "value", "data", "diff", "tariff_value", "nds", "uroven") 
			values (_values_set_id, _pre_pokaz+(190/_trans)*_person-(_last_kvt/_trans), _data+1, (90/_trans)*_person, tar, _nds, 2);

			tar = industry.uroven_tariff_value(_data,200,12);
		
			insert into industry.counter_value ("values_set_id", "value", "data", "diff", "tariff_value", "nds", "uroven") 
			values (_values_set_id, _value, _data+2, _kvt - (190/_trans)*_person+(_last_kvt/_trans), tar, _nds, 3);
			ind = true;
		end if;

	end if;

	if (_last_uroven = 2) then

		if ((_kvt*_trans)+_last_kvt <= 90*_person) then
			tar = industry.uroven_tariff_value(_data,90,12);
			insert into industry.counter_value ("values_set_id", "value", "data", "diff", "tariff_value", "nds", "uroven") 
			values (_values_set_id, _value, _data, _kvt, tar, _nds, 2);
			ind = true;
		end if;


		if ((_kvt*_trans)+_last_kvt > 90*_person) then
		if (_pre_pokaz+(90/_trans)*_person-(_last_kvt/_trans)>=razryadnost) then _pre_pokaz=_pre_pokaz-razryadnost;
		        end if;
			tar = industry.uroven_tariff_value(_data,90,12);
			insert into industry.counter_value ("values_set_id", "value", "data", "diff", "tariff_value", "nds", "uroven") 
			values (_values_set_id, _pre_pokaz+(90/_trans)*_person-(_last_kvt/_trans), _data, (90/_trans)*_person-(_last_kvt/_trans), tar, _nds, 2);	

			tar = industry.uroven_tariff_value(_data,200,12);
		
			insert into industry.counter_value ("values_set_id", "value", "data", "diff", "tariff_value", "nds", "uroven") 
			values (_values_set_id, _value, _data+1, _kvt-((90/_trans)*_person-(_last_kvt/_trans)) , tar, _nds, 3);
			ind = true;
		end if;
	end if;

	if (_last_uroven = 3) then

			tar = industry.uroven_tariff_value(_data,200,12);
			insert into industry.counter_value ("values_set_id", "value", "data", "diff", "tariff_value", "nds", "uroven") 
			values (_values_set_id, _value, _data, _kvt, tar, _nds, 3);
			ind = true;
	end if;
	end if;
	
else

	if (_uroven=0) then 

		if (_nadbavka_ur = 3) then
			tar = industry.uroven_tariff_value(_data,200,12);
			insert into industry.counter_value ("values_set_id", "value", "data", "diff", "tariff_value", "nds", "uroven") 
			values (_values_set_id, _value, _data, _kvt, tar, _nds, 3);
			ind = true;
		end if;


		if (_nadbavka_ur = 2) then

			if(_last_uroven = 3) then

				tar = industry.uroven_tariff_value(_data,200,12);
				insert into industry.counter_value ("values_set_id", "value", "data", "diff", "tariff_value", "nds", "uroven") 
				values (_values_set_id, _value, _data, _kvt, tar, _nds, 3);
				ind = true;
			else
		
				if (((_kvt*_trans)+(_nadbavka_ost+_last_kvt))>90*_person) then
				if (_pre_pokaz+(90/_trans)*_person- (_nadbavka_ost+_last_kvt)/_trans>=razryadnost) then _pre_pokaz=_pre_pokaz-razryadnost;
		        end if;
					tar = industry.uroven_tariff_value(_data,90,12);
					insert into industry.counter_value ("values_set_id", "value", "data", "diff", "tariff_value", "nds", "uroven") 
					values (_values_set_id, _pre_pokaz+(90/_trans)*_person- (_nadbavka_ost+_last_kvt)/_trans, _data, (90/_trans)*_person- (_nadbavka_ost+_last_kvt)/_trans, tar, _nds, 2);	

					tar = industry.uroven_tariff_value(_data,200,12);
			
					insert into industry.counter_value ("values_set_id", "value", "data", "diff", "tariff_value", "nds", "uroven") 
					values (_values_set_id, _value, _data+1, _kvt -(90/_trans)*_person+ (_nadbavka_ost+_last_kvt)/_trans, tar, _nds, 3);
					ind = true;
				else	 
	
					tar = industry.uroven_tariff_value(_data,90,12);
		
					insert into industry.counter_value ("values_set_id", "value", "data", "diff", "tariff_value", "nds", "uroven") 
					values (_values_set_id, _value, _data, _kvt, tar, _nds, 2);
					ind = true;
				end if;
			end if;

			
		end if;

		if (_nadbavka_ur = 1) then

			if(_last_uroven = 2) then

				if (((_kvt*_trans)+(_nadbavka_ost+_last_kvt))>90*_person) then
				if (_pre_pokaz+(90/_trans)*_person- (_nadbavka_ost+_last_kvt)/_trans>=razryadnost) then _pre_pokaz=_pre_pokaz-razryadnost;
		        end if;
					tar = industry.uroven_tariff_value(_data,90,12);
					insert into industry.counter_value ("values_set_id", "value", "data", "diff", "tariff_value", "nds", "uroven") 
					values (_values_set_id, _pre_pokaz+(90/_trans)*_person- (_nadbavka_ost+_last_kvt)/_trans, _data, (90/_trans)*_person- (_nadbavka_ost+_last_kvt)/_trans, tar, _nds, 2);	

					tar = industry.uroven_tariff_value(_data,200,12);
				
					insert into industry.counter_value ("values_set_id", "value", "data", "diff", "tariff_value", "nds", "uroven") 
					values (_values_set_id, _value, _data+1, _kvt -(90/_trans)*_person+ (_nadbavka_ost+_last_kvt)/_trans, tar, _nds, 3);
					ind = true;
				else	 
	
					tar = industry.uroven_tariff_value(_data,90,12);
		
					insert into industry.counter_value ("values_set_id", "value", "data", "diff", "tariff_value", "nds", "uroven") 
					values (_values_set_id, _value, _data, _kvt, tar, _nds, 2);
					ind = true;
				end if;
			end if;

			if(_last_uroven = 3) then

				tar = industry.uroven_tariff_value(_data,200,12);
				insert into industry.counter_value ("values_set_id", "value", "data", "diff", "tariff_value", "nds", "uroven") 
				values (_values_set_id, _value, _data, _kvt, tar, _nds, 3);
				ind = true;
			end if;


			if(_last_uroven = 1) then

				if (((_kvt*_trans)+(_nadbavka_ost+_last_kvt))>190*_person) then
if (_pre_pokaz+(100/_trans)*_person-(_nadbavka_ost+_last_kvt)/_trans>=razryadnost) then _pre_pokaz=_pre_pokaz-razryadnost;
		        end if;
					tar = industry.uroven_tariff_value(_data,100,12);
					insert into industry.counter_value ("values_set_id", "value", "data", "diff", "tariff_value", "nds", "uroven") 
					values (_values_set_id, _pre_pokaz+(100/_trans)*_person-(_nadbavka_ost+_last_kvt)/_trans, _data, (100/_trans)*_person-(_nadbavka_ost+_last_kvt)/_trans, tar, _nds, 1);
	if (_pre_pokaz-(_nadbavka_ost+_last_kvt)/_trans+(190/_trans)*_person>=razryadnost) then _pre_pokaz=_pre_pokaz-razryadnost;
		        end if;
					tar = industry.uroven_tariff_value(_data,90,12);
					insert into industry.counter_value ("values_set_id", "value", "data", "diff", "tariff_value", "nds", "uroven") 
					values (_values_set_id, _pre_pokaz-(_nadbavka_ost+_last_kvt)/_trans+(190/_trans)*_person, _data+1, (90/_trans)*_person, tar, _nds, 2);

					tar = industry.uroven_tariff_value(_data,200,12);
		
					insert into industry.counter_value ("values_set_id", "value", "data", "diff", "tariff_value", "nds", "uroven") 
					values (_values_set_id, _value, _data+2, _kvt - ((190/_trans)*_person-(_nadbavka_ost+_last_kvt)/_trans), tar, _nds, 3);
					ind = true; 
		
				end if;

				if (((_kvt*_trans)+(_nadbavka_ost+_last_kvt))>100*_person) and (((_kvt*_trans)+(_nadbavka_ost+_last_kvt))<=190*_person) then
		if (_pre_pokaz+(100/_trans)*_person-(_nadbavka_ost+_last_kvt)/_trans>=razryadnost) then _pre_pokaz=_pre_pokaz-razryadnost;
		        end if;
					tar = industry.uroven_tariff_value(_data,100,12);
					insert into industry.counter_value ("values_set_id", "value", "data", "diff", "tariff_value", "nds", "uroven") 
					values (_values_set_id, _pre_pokaz+(100/_trans)*_person-(_nadbavka_ost+_last_kvt)/_trans, _data, (100/_trans)*_person-(_nadbavka_ost+_last_kvt)/_trans, tar, _nds, 1);

					tar = industry.uroven_tariff_value(_data,90,12);
	
					insert into industry.counter_value ("values_set_id", "value", "data", "diff", "tariff_value", "nds", "uroven") 
					values (_values_set_id, _value, _data+1, _kvt - ((100/_trans)*_person-(_nadbavka_ost+_last_kvt)/_trans), tar, _nds, 2);
					ind = true; 
				end if;

				if (((_kvt*_trans)+(_nadbavka_ost+_last_kvt))<=100*_person) then

					tar = industry.uroven_tariff_value(_data,100,12);
					insert into industry.counter_value ("values_set_id", "value", "data", "diff", "tariff_value", "nds", "uroven") 
					values (_values_set_id, _value, _data, _kvt, tar, _nds, 1);
		
					ind = true; 
				end if;
			end if;


		end if;


	end if;
end if;











end if;

end;
$$;

