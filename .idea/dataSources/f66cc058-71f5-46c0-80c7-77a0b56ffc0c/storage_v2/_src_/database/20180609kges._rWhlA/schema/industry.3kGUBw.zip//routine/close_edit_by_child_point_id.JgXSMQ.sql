create function close_edit_by_child_point_id()
  returns trigger
language plpgsql
as $$
declare
	_firm_id integer;
	_period_id integer;
	_error integer;
	_current_period integer;
begin
	
	if (TG_OP='INSERT') or (TG_OP='UPDATE') then
		select firm_id from industry.billing_point
		where  id=NEW.child_point_id into _firm_id;
	end if;

	if TG_OP='DELETE' then
		select firm_id from industry.billing_point
		where  id=OLD.child_point_id into _firm_id;
	end if;
	
	select value::integer from industry.sprav where name='current_period' into _current_period;

	select id from industry.firm_close 
	where period_id=_current_period and firm_id=_firm_id
	into _error;

	if _error is not null then 
		raise exception 'firm closed';
	end if;
	if (TG_OP='INSERT') or (TG_OP='UPDATE') then
		return NEW;
	end if;
	if TG_OP='DELETE' then
		return OLD;
	end if;
	
end;
$$;

