create function data_verify_on_insert()
  returns trigger
language plpgsql
as $$
declare 
date_start date;
date_end date;

begin
select period.begin_date,period.end_date from industry.period
         left join industry.sprav on period.id=sprav.value::integer
           where sprav.name='current_period' into date_start,date_end;
   if NEW.data<date_start or NEW.data>date_end then
   raise exception 'data verify';
     return NULL;
     
   end if;
return new;
end;
$$;

