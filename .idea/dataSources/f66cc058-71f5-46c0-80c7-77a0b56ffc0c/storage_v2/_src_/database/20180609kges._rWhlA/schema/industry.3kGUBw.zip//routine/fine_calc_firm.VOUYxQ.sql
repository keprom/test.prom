create function fine_calc_firm(id_firm integer, id_period integer, _day integer DEFAULT NULL::integer)
  returns numeric
language plpgsql
as $$
DECLARE
  days_count INTEGER;
  buf_row RECORD;
  buf_row2 RECORD;
  current_ref_rate NUMERIC;
  current_ref_coef NUMERIC;
  temp_rate_value NUMERIC;
  temp_coef_value NUMERIC;
  fine_new NUMERIC;
  fine_old NUMERIC;
  dolg_new NUMERIC;
  dolg_old NUMERIC;
  day_buf_old INTEGER;
  border_day INTEGER;
  k NUMERIC;
  opl NUMERIC;
  hash_text TEXT;
  is_calendar INTEGER;
  days_in_year INTEGER;
  is_budget BOOLEAN;
  _nach NUMERIC;
  _saldo NUMERIC;
  do_fine BOOLEAN;
  
BEGIN

  --начисляется ли пеня?
  SELECT is_fine
  FROM industry.fine_firm
  WHERE firm_id = id_firm AND period_id = id_period
  INTO do_fine;
  do_fine := COALESCE(do_fine, FALSE); 

  IF do_fine = FALSE THEN RETURN 0; END IF;

  --выясняем является ли организация бюджетной или ей подобной (жылу, су)
  SELECT 
	CASE
            WHEN firm_group.name::text ~~ '%Бюджет%'::text OR fine_as_budget.firm_id IS NOT NULL THEN true
            ELSE false
        END AS is_budget
  FROM industry.firm_group
  JOIN industry.firm_subgroup ON firm_subgroup.group_id = firm_group.id
  JOIN industry.firm ON firm.subgroup_id = firm_subgroup.id
  LEFT JOIN industry.fine_as_budget ON fine_as_budget.firm_id = firm.id AND fine_as_budget.period_id = id_period
  WHERE firm.id = id_firm
  INTO is_budget;

  --fail #1
  IF (id_period<116) THEN 
    is_budget := TRUE;
  END IF;

  --вытаскиваем начисления за прошлый месяца (бюджет*) или за текущий (небюджет)
  IF is_budget = TRUE 
    THEN 
      BEGIN 
	SELECT itogo_with_nds
	FROM industry.firm_itog_vedomost 
	WHERE firm_id = id_firm AND period_id = (id_period-1)
	INTO _nach;
      END; 
    ELSE 
      BEGIN 
	SELECT itogo_with_nds
	FROM industry.firm_itog_vedomost 
	WHERE firm_id = id_firm AND period_id = id_period
	INTO _nach;
      END ;
  END IF;
  _nach := COALESCE(_nach, 0);

  --вытаскиваем сальдо на начало месяца
  SELECT value
  FROM industry.saldo
  WHERE firm_id = id_firm AND period_id = id_period
  INTO _saldo;
  _saldo := COALESCE(_saldo, 0);

  dolg_new := _nach;
  dolg_old := _saldo - dolg_new;
  fine_new := 0;
  fine_old := 0;
  day_buf_old := 0;
  k := 0;

  --дней в году
  SELECT fine_calendar.day_of_year 
  FROM industry.fine_calendar
  JOIN industry.period 
    ON EXTRACT (YEAR FROM period.begin_date) = fine_calendar."year" 
    AND fine_calendar."month" = 12
    AND fine_calendar."day" = 31
  INTO days_in_year;

  --начисление после n-дней календарных или рабочих
  SELECT fine_firm.is_calendar
  FROM industry.fine_firm
  WHERE firm_id = id_firm AND period_id = id_period
  INTO is_calendar;

  --граничный день
  SELECT fine_firm.border_day 
  FROM industry.fine_firm
  WHERE firm_id = id_firm AND period_id = id_period
  INTO border_day;

  --если рабочих
  IF (is_calendar = 0) THEN
    SELECT industry.get_working_day(id_period, border_day) INTO border_day;
  END IF;

  --создание хэша для разделения пространства между пользователями
  SELECT MD5(random()::text) INTO hash_text;
  
  --возврат 0 если сальдо меньше или равно нулю
  IF (_saldo <= 0) THEN RETURN 0; END IF;

  --получение действующей на начало месяца ставки рефинансирования
  SELECT ref_rate.value 
  FROM industry.ref_rate, industry.period 
  WHERE ref_rate.data<=period.begin_date AND period.id = id_period
  ORDER BY ref_rate.data DESC 
  LIMIT 1 
  INTO current_ref_rate;

  --получение действующего на начало месяца коэффициента рефинансирования
  SELECT ref_coef.value 
  FROM industry.ref_coef, industry.period 
  WHERE ref_coef.data<=period.begin_date AND period.id = id_period
  ORDER BY ref_coef.data DESC 
  LIMIT 1 
  INTO current_ref_coef;

  --поиск количества дней в рассчетном месяце
  SELECT industry.get_days_count(period.end_date) 
  FROM industry.period 
  WHERE period.id = id_period 
  INTO days_count;
  
  --заполнение временной таблицы исходными данными
  FOR i IN 0..days_count LOOP
    INSERT INTO industry.fine_oplata_buf (day, firm_id,hash) VALUES (i, id_firm, hash_text);
  END LOOP;

  --обновляем если была оплата
  FOR buf_row IN
    SELECT 
      oplata.data AS data,
      SUM(((oplata.value * (100::NUMERIC + oplata.nds)))/100)::NUMERIC AS value
    FROM industry.oplata
    JOIN industry.period ON oplata.data>=period.begin_date AND oplata.data<=period.end_date
    WHERE period.id = id_period AND oplata.firm_id = id_firm
    GROUP BY oplata.data
  LOOP
    UPDATE industry.fine_oplata_buf 
      SET value = buf_row.value 
    WHERE fine_oplata_buf.day = industry.get_day(buf_row.data) AND firm_id = id_firm AND hash = hash_text;
  END LOOP;

  /*проход по оплатам*/  
  FOR buf_row2 IN
    SELECT * 
    FROM industry.fine_oplata_buf
    WHERE firm_id = id_firm AND hash = hash_text
    ORDER BY day
  LOOP
    /*вносим если есть изменени по ставке рефинансирования*/
    SELECT ref_rate.value FROM industry.ref_rate 
    JOIN industry.period ON ref_rate.data>=period.begin_date AND ref_rate.data<=period.end_date
    WHERE industry.get_day(ref_rate.data) = buf_row2.day AND period.id = id_period
    INTO temp_rate_value;
    current_ref_rate := COALESCE(temp_rate_value, current_ref_rate); 

    /*вносим если есть изменения по коэффициенту рефинансирования*/
    SELECT ref_coef.value FROM industry.ref_coef 
    JOIN industry.period ON ref_coef.data>=period.begin_date AND ref_coef.data<=period.end_date
    WHERE industry.get_day(ref_coef.data) = buf_row2.day AND period.id = id_period
    INTO temp_coef_value;
    current_ref_coef := COALESCE(temp_coef_value, current_ref_coef); 
    
    k := current_ref_coef * (current_ref_rate * 0.01) / days_in_year;

    /*отнимаем оплату со старого долга или нового*/
    opl := buf_row2.value;
    IF ((dolg_old::INTEGER = 0) AND (dolg_new::INTEGER = 0)) THEN
 	opl := 0;
    END IF;
    
    IF (dolg_old > 0) THEN
	dolg_old := (dolg_old - opl);
	opl := 0::INTEGER;
    END IF;
    
    IF (dolg_old < 0) THEN
	dolg_new := dolg_new + dolg_old;
	dolg_old := 0::INTEGER;
    END IF;
    
    IF (dolg_old::INTEGER = 0) THEN
	IF (dolg_new > 0) THEN
		dolg_new := (dolg_new - opl);
	END IF;
    END IF;
    
    IF (dolg_new < 0) THEN
	dolg_new := 0::INTEGER;
    END IF;
    
    /*начисляем пеню, если есть на что*/
    IF (dolg_old > 0) THEN
	fine_old := fine_old + (buf_row2.day - day_buf_old) * k * dolg_old;
    END IF;
    
    IF (dolg_new > 0) THEN
	IF (buf_row2.day > border_day) THEN
		fine_new := fine_new + (buf_row2.day - day_buf_old) * k * dolg_new;
	END IF;
    END IF;
    day_buf_old := buf_row2.day;
    
    /*день выдачи, прерываем расчет пени*/
    IF ((_day IS NOT NULL) AND ( _day = buf_row2.day) ) THEN 
        EXIT;
    END IF;	
	
  END LOOP;

  --очистка временной таблицы для хранения значения оплат
  DELETE FROM industry.fine_oplata_buf WHERE firm_id = id_firm AND hash = hash_text;
    
  RETURN (fine_old+fine_new)::NUMERIC(24,2);
  
END;

$$;

comment on function fine_calc_firm(id_firm integer, id_period integer, _day integer DEFAULT NULL :: integer)
is 'Рассчитывает пеню для организации';

