create view ip_obshiy_tar as
  SELECT vedomost.firm_name, vedomost.bill_name, vedomost.gos_nomer, vedomost.period_id, vedomost.dogovor FROM (industry."vedomost-2numround" vedomost LEFT JOIN industry.firm ON ((firm.id = vedomost.firm_id))) WHERE ((((vedomost.tariff_name)::text = 'Общий'::text) AND (vedomost.neuchtennyy = (0)::numeric)) AND (firm.subgroup_id <> 12)) ORDER BY vedomost.firm_name;

