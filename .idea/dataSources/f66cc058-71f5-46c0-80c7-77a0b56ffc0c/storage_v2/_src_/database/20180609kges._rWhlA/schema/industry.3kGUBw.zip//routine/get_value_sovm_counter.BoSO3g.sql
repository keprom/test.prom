create function get_value_sovm_counter(id_bill integer, id_period integer)
  returns numeric
language plpgsql
as $$
DECLARE
c_value NUMERIC;
BEGIN
SELECT SUM( (-1) :: NUMERIC * counter_value.diff * counter.transform :: NUMERIC )::NUMERIC(24,2)
FROM industry.sovm_by_counter_value
LEFT JOIN industry.period ON period.id = sovm_by_counter_value.period_id
LEFT JOIN industry.billing_point ON billing_point.id = sovm_by_counter_value.billing_point_id
LEFT JOIN industry.counter ON counter.point_id = billing_point.id
LEFT JOIN industry.values_set ON values_set.counter_id = counter.id
LEFT JOIN industry.counter_value ON counter_value.values_set_id = values_set.id and counter_value.data>=period.begin_date and counter_value.data<=period.end_date
WHERE billing_point.id = id_bill and period.id = id_period and counter_value.diff <> 0::NUMERIC
INTO c_value;
 c_value := coalesce(c_value, 0);
RETURN c_value;
END;
$$;

