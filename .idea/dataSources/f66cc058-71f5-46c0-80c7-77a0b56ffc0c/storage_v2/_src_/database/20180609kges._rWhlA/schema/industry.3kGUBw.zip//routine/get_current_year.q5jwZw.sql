create function get_current_year()
  returns integer
language plpgsql
as $$
DECLARE current_year INTEGER;
BEGIN

SELECT EXTRACT (YEAR FROM period.end_date)
FROM industry.period
WHERE period.id = industry.current_period_id()
INTO current_year;

RETURN current_year;

END;
$$;

