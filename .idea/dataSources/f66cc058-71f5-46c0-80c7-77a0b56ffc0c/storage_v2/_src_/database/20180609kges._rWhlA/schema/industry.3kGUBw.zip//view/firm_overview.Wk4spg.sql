create view firm_overview as
  SELECT firm.id AS firm_id, firm.name AS firm_name, firm.dogovor, firm.rnn, firm.director_name, firm.firm_closed, firm.dogovor_date, firm.subgroup_id, firm.address AS firm_address, firm.bank_id, firm.telefon, firm_close.id AS is_closed, firm.user_id, firm.close_type, firm.bin FROM ((industry.firm LEFT JOIN industry.sprav ON (((sprav.name)::text = 'current_period'::text))) LEFT JOIN industry.firm_close ON (((firm.id = firm_close.firm_id) AND ((firm_close.period_id)::numeric = sprav.value))));

