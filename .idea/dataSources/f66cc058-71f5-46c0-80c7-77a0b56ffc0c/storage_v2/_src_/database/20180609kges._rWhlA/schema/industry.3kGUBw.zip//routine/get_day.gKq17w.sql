create function get_day(input_date date)
  returns integer
language plpgsql
as $$
declare month_number INTEGER;
begin
SELECT EXTRACT(DAY FROM input_date) into month_number;
return month_number;
end;
$$;

