create function "On_delete_pokaz"()
  returns trigger
language plpgsql
as $$
declare 
 cmd text;
 buf_val numeric(24,4); 	buf_dif numeric(24,4);
 buf_dif_tariff numeric(24,4);  buf_data date;
 buf_data2 date; 		buf_val2 numeric(24,4);
 razryadnost numeric(24,4); 		_val numeric(24,4);
 date_start date;		date_finish date;
 buf_id integer;		tariff_id integer;
 _tariff_value numeric(24,4);
 buf_id2 integer;

begin

-- ПОЛУЧАЕМ ДАННЫЕ О СЧЕТЧИКЕ
select digit_count,data_start,data_finish,values_set.tariff_id from industry.counter
	        left join industry.values_set on counter.id=values_set.counter_id
	        where values_set.id=OLD.values_set_id 
	  into razryadnost,date_start,date_finish,tariff_id;

if date_finish is not  null then 
 raise exception 'schetchik uje snyat';
end if;

--- Вытаскиваем дату, и значение последних показаний по этой точке учета
select value,data,id from industry.counter_value 
   where values_set_id = OLD.values_set_id 
    and data=(
               select MIN(data) from industry.counter_value 
                 where values_set_id=OLD.values_set_id and data>OLD.data
               )
 into buf_val,buf_data,buf_id ;
 
if buf_val is not null then 
   -- ВЫТАСКИВАЕМ ДАННЫЕ О ПРЕДЫДУЩИХ ПОКАЗАНИЯХ
	select value,data,id from industry.counter_value 
	   where values_set_id = OLD.values_set_id 
	    and data=(
		       select MAX(data) from industry.counter_value 
			 where values_set_id=OLD.values_set_id and data<OLD.data
		       )
	 into buf_val2,buf_data2,buf_id2 ;
	 if buf_val2 is null then  
	    update industry.counter_value set diff=0 where id=buf_id;
	 else 
	    razryadnost:=pow(10,razryadnost);
	    buf_dif=buf_val-buf_val2;
	    if buf_dif<0   then buf_dif=razryadnost-buf_dif; end if;
	    buf_dif_tariff=buf_dif*30.0/(buf_data-buf_data2);
	    buf_dif= abs(buf_dif);
	    buf_dif_tariff=abs(buf_dif_tariff);
	    select industry.tariff_by_data_kvt_tariffid(buf_data,buf_dif_tariff,tariff_id) into _tariff_value;
	    update industry.counter_value set diff=buf_dif,tariff_value=_tariff_value where id=buf_id;
	 end if;
end if;

return OLD;
end;
$$;

