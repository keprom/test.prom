create function get_working_day(id_period integer, missed_day integer)
  returns integer
language plpgsql
as $$
DECLARE
calendar_border_day INTEGER;
buf_row RECORD;
i INTEGER;

BEGIN

i := 0;

FOR buf_row IN
  SELECT 
    day_id,
    "day",
    is_off
  FROM industry.fine_calendar
  JOIN industry.period 
    ON EXTRACT(MONTH FROM period.begin_date) = fine_calendar."month"
    AND EXTRACT(YEAR FROM period.begin_date) = fine_calendar."year"
  WHERE period.id = id_period
  ORDER BY day_id
LOOP
 IF (buf_row.is_off = 0) THEN i:= i + 1; END IF;
 IF (i = missed_day) THEN 
   BEGIN
     calendar_border_day := buf_row."day";
     EXIT;
   END;
 END IF;
END LOOP; 

RETURN calendar_border_day;
END;
$$;

