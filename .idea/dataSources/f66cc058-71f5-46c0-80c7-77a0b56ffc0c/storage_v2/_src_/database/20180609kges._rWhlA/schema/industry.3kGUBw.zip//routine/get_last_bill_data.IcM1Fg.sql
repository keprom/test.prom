create function get_last_bill_data(id_bill integer, id_period integer)
  returns integer
language plpgsql
as $$
DECLARE
pp_id INTEGER;
BEGIN

select pp.id
from industry.poteri_period pp
where pp.bill_id = id_bill and pp.period_id<=id_period
order by pp.period_id desc
limit 1 into pp_id;

return pp_id;

END;
$$;

