create function goto_next_period()
  returns void
language plpgsql
as $$
declare _period_id integer;

begin

update industry.sprav set value=value::integer +1 where name='current_period';

insert into industry.saldo(firm_id,value,period_id)select 
firm_id
,
coalesce (debet_value,0)
-
coalesce (kredit_value,0)+
(
coalesce (nachisleno,0)-coalesce (oplata_value,0)
) as saldo_value
,
sprav.value::integer as period_id
 from industry."7-re" 
right join industry.sprav on 
sprav.value::integer-1="7-re".period_id
where  sprav.name='current_period';

insert into industry.nadbavka_otnositelnaya
 (value,billing_point_id,period_id)

select nadbavka_otnositelnaya.value,
nadbavka_otnositelnaya.billing_point_id,
sprav.value
from industry.nadbavka_otnositelnaya

left join industry.sprav on sprav.name='current_period'
where 
nadbavka_otnositelnaya.period_id=sprav.value::integer-1;


insert into industry.sovm_by_counter_value
(parent_firm_id,billing_point_id,
period_id)
select 
sovm_by_counter_value.parent_firm_id,
sovm_by_counter_value.billing_point_id,
sprav.value::integer
from industry.sovm_by_counter_value
left join industry.sprav on sprav.name='current_period'
where 

sovm_by_counter_value.period_id=sprav.value::integer-1;





insert into industry.sovmestnyy_uchet
(parent_firm_id,child_point_id,
period_id,value)
select 
sovmestnyy_uchet.parent_firm_id,
sovmestnyy_uchet.child_point_id,
sprav.value::integer,
sovmestnyy_uchet.value
from industry.sovmestnyy_uchet
left join industry.sprav on sprav.name='current_period'
where 

sovmestnyy_uchet.period_id=sprav.value::integer-1;

insert into 
industry.sovm_absolutnyy(parent_firm_id,value,data,values_set_id,tariff_value)

select sovm_absolutnyy.parent_firm_id,
sovm_absolutnyy.value,
t1.end_date,
sovm_absolutnyy.values_set_id,
-1 from industry.sovm_absolutnyy
left join industry.sprav on sprav.name='current_period'
left join industry.period t1 on sprav.value=t1.id
left join industry.period t2 on sprav.value-1=t2.id
where 
 sovm_absolutnyy.data between t2.begin_date and t2.end_date;

insert into industry.nadbavka_absolutnaya (value,values_set_id,data,tariff_value)

select 
nadbavka_absolutnaya.value,
nadbavka_absolutnaya.values_set_id,
t1.end_date,
-1

from industry.nadbavka_absolutnaya

left join industry.sprav on sprav.name='current_period'
left join industry.period t1 on sprav.value=t1.id
left join industry.period t2 on sprav.value-1=t2.id
where 
 nadbavka_absolutnaya.data between t2.begin_date and t2.end_date;

 insert into industry.schetfactura_date (
	firm_id,period_id,date,
	edit1, edit2, edit3,
	edit4, edit5,edit6,data_nakl )
  (
         select firm.id,t1.id,t1.end_date,
		 t3.edit1, t3.edit2,
		t3.edit3, t3.edit4, t3.edit5, 
                       t3.edit6,t1.end_date 
                from industry.firm 
		left join industry.sprav on sprav.name='current_period'
		left join industry.period t1 on sprav.value=t1.id
		left join industry.period t2 on sprav.value-1=t2.id
		left join industry.schetfactura_date t3 on t3.period_id=t2.id and  t3.firm_id=firm.id
 );


return;

end;
$$;

