create view firm_with_poter_full as
  SELECT firm_with_poter.firm_id, firm.name AS firm_name, firm.dogovor, billing_point.name AS bill_name, firm_with_poter.period_id, period.name AS period_name FROM (((industry.firm_with_poter LEFT JOIN industry.firm ON ((firm_with_poter.firm_id = firm.id))) LEFT JOIN industry.billing_point ON ((firm_with_poter.bill_id = billing_point.id))) LEFT JOIN industry.period ON ((firm_with_poter.period_id = period.id)));

