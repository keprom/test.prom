create function period_verify()
  returns trigger
language plpgsql
as $$
declare 
 _period_id integer;
begin
 select 
   value::integer from 
   industry.sprav where 
     name='current_period' into _period_id;
  if _period_id<>OLD.period_id then 
    raise exception 'Period ne tekushiy';
  end if;
return OLD;
end;
$$;

