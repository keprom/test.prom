create view current_akt as
  SELECT akt.id, akt.value, akt.values_set_id, akt.data, akt.tariff_value FROM ((industry.akt LEFT JOIN industry.period ON (((akt.data >= period.begin_date) AND (akt.data <= period.end_date)))) LEFT JOIN industry.sprav ON ((period.id = (sprav.value)::integer))) WHERE ((sprav.name)::text = 'current_period'::text);

