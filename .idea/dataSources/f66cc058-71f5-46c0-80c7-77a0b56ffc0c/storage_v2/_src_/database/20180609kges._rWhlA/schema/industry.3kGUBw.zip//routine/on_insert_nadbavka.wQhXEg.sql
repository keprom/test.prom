create function on_insert_nadbavka()
  returns trigger
language plpgsql
as $$
declare 
_tariff_value numeric(24,4);
buf_tariff_id integer;
_start date;
_end date;
end_tr boolean;


 begin
 select begin_date,end_date from industry.period
right join industry.sprav on sprav.name='current_period' and sprav.value=period.id
into _start,_end;
if (NEW.data>_end) or (NEW.data<_start) then 
raise exception 'vyhod iz diapazona'; 
end if;

 select tariff_id from 
 industry.values_set where id=NEW.values_set_id into buf_tariff_id;
 
if (buf_tariff_id<>12) then
 
NEW.tariff_value = industry.tariff_by_data_kvt_tariffid(NEW.data,new.value,buf_tariff_id);
if (NEW.tariff_value is null) then 
raise exception 'problemy s raschetom tariffa';
end if;

else 

if (new.uroven=0) then  
end_tr = industry.nadbavka_drob(new.value,new.values_set_id,new.data,new.tariff_value,new.ost,new.uroven);
if (end_tr = true) then
return null;
else
raise exception 'oshibka pri droblenii';
return null;
end if;
end if;
end if;
return NEW;
end;
$$;

