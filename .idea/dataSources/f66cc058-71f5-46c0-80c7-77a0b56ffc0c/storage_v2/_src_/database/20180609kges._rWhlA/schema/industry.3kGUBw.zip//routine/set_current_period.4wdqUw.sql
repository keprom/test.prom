create function set_current_period()
  returns trigger
language plpgsql
as $$
declare 
 period_id integer; 
begin
 select value::integer from
 industry.sprav where name='current_period' into NEW.period_id; 

return NEW;
end;
$$;

