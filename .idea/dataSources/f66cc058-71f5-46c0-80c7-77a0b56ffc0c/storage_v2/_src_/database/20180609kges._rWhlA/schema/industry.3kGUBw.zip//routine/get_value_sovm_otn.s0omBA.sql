create function get_value_sovm_otn(id_bill integer, id_period integer)
  returns numeric
language plpgsql
as $$
DECLARE
c_value NUMERIC;
BEGIN
SELECT SUM( counter.transform :: NUMERIC * counter_value.diff * (100 :: NUMERIC - sovmestnyy_uchet.value)/100 :: NUMERIC ) ::NUMERIC(24,2)
FROM industry.sovmestnyy_uchet
LEFT JOIN industry.period ON sovmestnyy_uchet.period_id = period.id
LEFT JOIN industry.billing_point ON sovmestnyy_uchet.child_point_id = billing_point.id
LEFT JOIN industry.counter ON counter.point_id = billing_point.id
LEFT JOIN industry.values_set ON values_set.counter_id = counter.id
LEFT JOIN industry.counter_value ON counter_value.values_set_id = values_set.id and counter_value.data>=period.begin_date and counter_value.data<=period.end_date
WHERE billing_point.id = id_bill and period.id = id_period and counter_value.diff <> 0 :: NUMERIC
INTO c_value;
 c_value := coalesce(c_value, 0);
RETURN c_value;
END;
$$;

