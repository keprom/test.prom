create function last_counter_value_value(_values_set_id integer, _data date)
  returns numeric
language plpgsql
as $$
declare 
  _value numeric;
begin
 select value from industry.counter_value where values_set_id=_values_set_id and data<_data order by data desc limit 1 into _value;
return _value;
end;
$$;

