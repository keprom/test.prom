create function current_period()
  returns text
strict
language plpgsql
as $$
declare period_name text;
begin
 select period.name from industry.period
 left join industry.sprav on period.id=sprav.value::integer
 where sprav.name='current_period' into period_name;

 return period_name;
end;
$$;

