create view only_obwii as
  SELECT tariff_period.id, tariff_period.data FROM industry.tariff_period WHERE (tariff_period.tariff_id = 1);

