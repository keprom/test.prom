create view svod_oplat_po_firmam as
  SELECT firm.dogovor, firm.name AS firm_name, sum(((oplata.value * (oplata.nds + (100)::numeric)) / (100)::numeric)) AS sum, period.id AS period_id FROM ((industry.firm LEFT JOIN industry.oplata ON ((firm.id = oplata.firm_id))) LEFT JOIN industry.period ON (((oplata.data >= period.begin_date) AND (oplata.data <= period.end_date)))) GROUP BY firm.dogovor, firm.name, period.id;

