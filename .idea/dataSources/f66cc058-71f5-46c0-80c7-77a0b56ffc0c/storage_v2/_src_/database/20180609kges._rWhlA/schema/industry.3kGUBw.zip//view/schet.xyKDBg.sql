create view schet as
  SELECT schetfactura.firm_id, schetfactura.period_id, (sum(schetfactura.tenge))::numeric(24,2) AS tenge, (sum(schetfactura.nds_value))::numeric(24,2) AS nds, (sum(schetfactura.with_nds))::numeric(24,2) AS with_nds FROM industry.schetfactura GROUP BY schetfactura.firm_id, schetfactura.period_id;

