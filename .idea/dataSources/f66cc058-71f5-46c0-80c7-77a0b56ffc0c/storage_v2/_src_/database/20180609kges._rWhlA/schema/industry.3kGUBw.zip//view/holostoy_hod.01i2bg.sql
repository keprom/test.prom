create view holostoy_hod as
  SELECT vedomost.dogovor, vedomost.firm_name, vedomost.period_id, billing_point.id AS bill_point_id, billing_point.name AS bill_point_name, vedomost.neuchtennyy, billing_point.tp_id, tp.name AS tp_name FROM ((industry."vedomost-2numround" vedomost LEFT JOIN industry.billing_point ON ((vedomost.firm_id = billing_point.firm_id))) LEFT JOIN industry.tp ON ((billing_point.tp_id = tp.id))) WHERE (vedomost.neuchtennyy > (0)::numeric) ORDER BY vedomost.dogovor;

