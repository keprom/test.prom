create function get_value_nad_abs(id_bill integer, id_period integer)
  returns numeric
language plpgsql
as $$
DECLARE
c_value NUMERIC;
BEGIN
SELECT SUM(nadbavka_absolutnaya.value)::NUMERIC(24,2)
FROM industry.nadbavka_absolutnaya
LEFT JOIN industry.values_set ON nadbavka_absolutnaya.values_set_id = values_set.id
LEFT JOIN industry.counter ON counter.id = values_set.counter_id
LEFT JOIN industry.billing_point ON billing_point.id = counter.point_id
LEFT JOIN industry.period ON nadbavka_absolutnaya.data >= period.begin_date AND nadbavka_absolutnaya.data <= period.end_date
WHERE billing_point.id = id_bill and period.id = id_period
INTO c_value;
 c_value := coalesce(c_value, 0);
RETURN c_value;
END;
$$;

