create function get_value_by_tariff_akt(id_bill integer, id_period integer)
  returns numeric
language plpgsql
as $$
DECLARE
c_value NUMERIC;
BEGIN
SELECT SUM(akt_with_tariff.kvt)::NUMERIC(24,2)
FROM industry.akt_with_tariff
LEFT JOIN industry.counter ON counter.id = akt_with_tariff.counter_id
LEFT JOIN industry.billing_point ON counter.point_id = billing_point.id
LEFT JOIN industry.firm ON firm.id = billing_point.firm_id
LEFT JOIN industry.period ON akt_with_tariff.data >= period.begin_date AND akt_with_tariff.data <= period.end_date
WHERE billing_point.id = id_bill and period.id = id_period
INTO c_value;
 c_value := coalesce(c_value, 0);
RETURN c_value;
END;
$$;

