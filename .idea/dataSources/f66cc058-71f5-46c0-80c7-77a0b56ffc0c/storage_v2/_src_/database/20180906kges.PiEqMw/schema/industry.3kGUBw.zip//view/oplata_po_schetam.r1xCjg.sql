create view oplata_po_schetam as
  SELECT firm.dogovor, firm.name AS firm_name, oplata.document_number, payment_number.number, oplata.data, ((oplata.value * (oplata.nds + (100)::numeric)) / (100)::numeric) AS sum, period.id AS period_id FROM (((industry.oplata LEFT JOIN industry.firm ON ((oplata.firm_id = firm.id))) LEFT JOIN industry.payment_number ON ((oplata.payment_number_id = payment_number.id))) LEFT JOIN industry.period ON (((oplata.data >= period.begin_date) AND (oplata.data <= period.end_date)))) ORDER BY oplata.data, payment_number.number, firm.dogovor;

