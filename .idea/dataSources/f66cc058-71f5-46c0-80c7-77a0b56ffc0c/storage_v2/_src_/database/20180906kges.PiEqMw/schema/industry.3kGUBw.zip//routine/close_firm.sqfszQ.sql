create function close_firm(_firm_id integer)
  returns void
language plpgsql
as $$
declare close_id integer;
_period_id integer;
begin
select value::integer from industry.sprav 
where sprav.name='current_period' into _period_id;

select  id from industry.firm_close
 
where period_id=_period_id  and firm_id=_firm_id
 into close_id;

if (close_id is null) then
 insert into industry.firm_close (firm_id,period_id) values (_firm_id,_period_id);
end if;
return;
end;
$$;

