create function "On_Update_Pokaz"()
  returns trigger
language plpgsql
as $$
declare 
 buf_id integer;		
begin


if ((NEW.value<>OLD.value) or (NEW.data<>OLD.data) or (NEW.values_set_id<>OLD.values_set_id))
then
		delete from industry.counter_value where id=OLD.id;
		insert into industry.counter_value (values_set_id,value,data) values (NEW.values_set_id,NEW.value,NEW.data);
		select id from industry.counter_value where values_set_id=NEW.values_set_id and data=NEW.data into buf_id;
		if buf_id is null then  ROLLBACK; end if;
end if;
return NEW;
end;
$$;

