create view schetfactura as
  SELECT vedomost.firm_id, vedomost.tariff_value, (vedomost.nds)::numeric(24,0) AS nds, sum(my_round(vedomost.itogo_kvt)) AS kvt, sum(my_round(vedomost.itogo_tenge)) AS tenge, (my_round(((sum(vedomost.itogo_tenge) * vedomost.nds) / (100)::numeric)))::numeric(24,2) AS nds_value, (my_round(((sum(vedomost.itogo_tenge) * ((100)::numeric + vedomost.nds)) / (100)::numeric)))::numeric(24,2) AS with_nds, vedomost.period_id FROM industry."vedomost-2numround" vedomost GROUP BY vedomost.firm_id, vedomost.tariff_value, vedomost.nds, vedomost.period_id;

