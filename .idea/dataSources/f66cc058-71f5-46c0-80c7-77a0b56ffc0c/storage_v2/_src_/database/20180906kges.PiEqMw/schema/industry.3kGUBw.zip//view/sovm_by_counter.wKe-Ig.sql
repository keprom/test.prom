create view sovm_by_counter as
  SELECT sovm_by_counter_value.id AS sov_id, firm.name AS firm_name, sovm_by_counter_value.billing_point_id, sovm_by_counter_value.period_id FROM (industry.sovm_by_counter_value LEFT JOIN industry.firm ON ((sovm_by_counter_value.parent_firm_id = firm.id)));

