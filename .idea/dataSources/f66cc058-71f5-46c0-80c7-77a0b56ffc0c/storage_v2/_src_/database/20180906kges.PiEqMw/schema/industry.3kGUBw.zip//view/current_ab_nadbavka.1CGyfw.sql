create view current_ab_nadbavka as
  SELECT nadbavka_absolutnaya.id, nadbavka_absolutnaya.value, nadbavka_absolutnaya.values_set_id, nadbavka_absolutnaya.data, nadbavka_absolutnaya.tariff_value FROM ((industry.nadbavka_absolutnaya LEFT JOIN industry.period ON (((nadbavka_absolutnaya.data >= period.begin_date) AND (nadbavka_absolutnaya.data <= period.end_date)))) LEFT JOIN industry.sprav ON ((period.id = (sprav.value)::integer))) WHERE ((sprav.name)::text = 'current_period'::text);

