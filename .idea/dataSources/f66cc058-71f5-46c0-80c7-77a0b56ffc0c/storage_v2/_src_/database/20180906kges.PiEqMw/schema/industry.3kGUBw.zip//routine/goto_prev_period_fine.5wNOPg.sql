create function goto_prev_period_fine()
  returns void
language plpgsql
as $$
declare 
cut_period INTEGER;
cut_end_date DATE;
begin
select (sprav.value::INTEGER-1)::INTEGER from industry.sprav where sprav.name='current_period' into cut_period;
select period.end_date from industry.period where period.id=cut_period into cut_end_date;

ALTER TABLE industry.nadbavka_absolutnaya DISABLE TRIGGER ALL;
ALTER TABLE industry.nadbavka_otnositelnaya DISABLE TRIGGER ALL;
ALTER TABLE industry.sovm_absolutnyy DISABLE TRIGGER ALL;
ALTER TABLE industry.sovm_by_counter_value DISABLE TRIGGER ALL;
ALTER TABLE industry.sovmestnyy_uchet DISABLE TRIGGER ALL;

update industry.sprav set value=cut_period where name='current_period';

delete from industry.nadbavka_absolutnaya where data>cut_end_date;

delete from industry.nadbavka_otnositelnaya where period_id> cut_period;

delete from industry.schetfactura_date where period_id>cut_period;

delete from industry.saldo where period_id>cut_period;

delete from industry.sovm_absolutnyy where data>cut_end_date;

delete from industry.sovm_by_counter_value where period_id>cut_period;

delete from industry.sovmestnyy_uchet where period_id>cut_period;

delete from industry.firm_close where period_id>cut_period;

delete from industry.fine_saldo where period_id>cut_period;

delete from industry.fine_firm where period_id>cut_period;

delete from industry.fine_as_budget where period_id>cut_period;

ALTER TABLE industry.nadbavka_absolutnaya ENABLE TRIGGER ALL;
ALTER TABLE industry.nadbavka_otnositelnaya ENABLE TRIGGER ALL;
ALTER TABLE industry.sovm_absolutnyy ENABLE TRIGGER ALL;
ALTER TABLE industry.sovm_by_counter_value ENABLE TRIGGER ALL;
ALTER TABLE industry.sovmestnyy_uchet ENABLE TRIGGER ALL;

end;
$$;

