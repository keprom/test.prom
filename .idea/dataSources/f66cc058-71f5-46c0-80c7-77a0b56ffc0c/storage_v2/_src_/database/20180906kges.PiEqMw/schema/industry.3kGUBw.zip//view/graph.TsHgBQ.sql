create view graph as
  SELECT "7-re".firm_id, COALESCE("7-re".itogo_kvt, (0)::numeric) AS itogo_kvt, period.name AS period_name, period.begin_date AS period_begin_date, period.id AS period_id FROM (industry."7-re" LEFT JOIN industry.period ON ((period.id = "7-re".period_id))) ORDER BY "7-re".period_id;

