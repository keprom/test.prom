create function goto_next_period_fine()
  returns void
language plpgsql
as $$
DECLARE _period_id INTEGER;

BEGIN

  UPDATE industry.sprav
  SET value = value :: INTEGER + 1
  WHERE name = 'current_period';

  /*вставка в таблицу пеневого сальдо*/
  INSERT INTO industry.fine_saldo (firm_id, period_id, value)
    SELECT
      firm.id,
      (period.id+1),
      (coalesce(fs.value,0)+coalesce(fine_source_data.fine_value,0)-coalesce(sum(fine_oplata.value * ((period.nds + 100) / 100)), 0))
    FROM industry.firm
      JOIN industry.period ON 1 = 1
      JOIN industry.sprav ON sprav.value :: INTEGER - 1 = period.id AND sprav.name = 'current_period'
      LEFT JOIN industry.fine_source_data ON fine_source_data.period_id = period.id AND fine_source_data.firm_id = firm.id
      LEFT JOIN industry.fine_saldo fs ON fs.firm_id = firm.id AND fs.period_id = period.id
      LEFT JOIN industry.fine_oplata
        ON fine_oplata.data >= period.begin_date AND fine_oplata.data <= period.end_date AND fine_oplata.firm_id = firm.id
    GROUP BY firm.id, period.id, fs.value, fine_source_data.fine_value;

  /*параметры пени*/
  INSERT INTO industry.fine_firm (firm_id, period_id, border_day, is_fine, is_calendar)
    SELECT 
	firm_id,
	period_id+1,
	border_day,
	is_fine,
	is_calendar
    FROM industry.fine_firm
    JOIN industry.period ON period.id = period_id
    JOIN industry.sprav ON sprav.value :: INTEGER - 1 = period.id AND sprav.name = 'current_period';

  /*вставка в таблицу сальдо*/
  INSERT INTO industry.saldo (firm_id, value, period_id)
    SELECT
      firm.id,
      (
       saldo.value + 
       coalesce(firm_itog_vedomost.itogo_with_nds, 0) -
       coalesce(sum(oplata.value * ((period.nds + 100) / 100)), 0)
      ) AS saldo_end_value,
      period.id+1 as period_id
    FROM industry.firm
      JOIN industry.period ON 1 = 1
      JOIN industry.sprav ON sprav.value :: INTEGER - 1 = period.id AND sprav.name = 'current_period'
      LEFT JOIN industry.firm_itog_vedomost
        ON firm_itog_vedomost.firm_id = firm.id AND period.id = firm_itog_vedomost.period_id
      LEFT JOIN industry.saldo ON saldo.firm_id = firm.id AND saldo.period_id = period.id
      LEFT JOIN industry.oplata
        ON oplata.data >= period.begin_date AND oplata.data <= period.end_date AND oplata.firm_id = firm.id
    GROUP BY
      firm.id,
      saldo.value,
      firm_itog_vedomost.itogo_with_nds,
      period.id;

  /*вставка исходных данных в относительные надбавки*/
  INSERT INTO industry.nadbavka_otnositelnaya
  (value, billing_point_id, period_id)
    SELECT
      nadbavka_otnositelnaya.value,
      nadbavka_otnositelnaya.billing_point_id,
      sprav.value
    FROM industry.nadbavka_otnositelnaya
      LEFT JOIN industry.sprav ON sprav.name = 'current_period'
    WHERE
      nadbavka_otnositelnaya.period_id = sprav.value :: INTEGER - 1;

  /*вставка исходных данных в совместный учет по счетчику*/
  INSERT INTO industry.sovm_by_counter_value
  (parent_firm_id, billing_point_id,
   period_id)
    SELECT
      sovm_by_counter_value.parent_firm_id,
      sovm_by_counter_value.billing_point_id,
      sprav.value :: INTEGER
    FROM industry.sovm_by_counter_value
      LEFT JOIN industry.sprav ON sprav.name = 'current_period'
    WHERE
      sovm_by_counter_value.period_id = sprav.value :: INTEGER - 1;

  /*вставка исходных данных в совместный процентный учет*/
  INSERT INTO industry.sovmestnyy_uchet
  (parent_firm_id, child_point_id,
   period_id, value)
    SELECT
      sovmestnyy_uchet.parent_firm_id,
      sovmestnyy_uchet.child_point_id,
      sprav.value :: INTEGER,
      sovmestnyy_uchet.value
    FROM industry.sovmestnyy_uchet
      LEFT JOIN industry.sprav ON sprav.name = 'current_period'
    WHERE
      sovmestnyy_uchet.period_id = sprav.value :: INTEGER - 1;

  /*вставка исходных данных в совместный абсолютный учет*/
  INSERT INTO
    industry.sovm_absolutnyy (parent_firm_id, value, data, values_set_id, tariff_value)
    SELECT
      sovm_absolutnyy.parent_firm_id,
      sovm_absolutnyy.value,
      t1.end_date,
      sovm_absolutnyy.values_set_id,
      -1
    FROM industry.sovm_absolutnyy
      LEFT JOIN industry.sprav ON sprav.name = 'current_period'
      LEFT JOIN industry.period t1 ON sprav.value = t1.id
      LEFT JOIN industry.period t2 ON sprav.value - 1 = t2.id
    WHERE
      sovm_absolutnyy.data BETWEEN t2.begin_date AND t2.end_date;

  /*вставка исходных данных в абсолютные надбавки*/
  INSERT INTO industry.nadbavka_absolutnaya (value, values_set_id, data, tariff_value)
    SELECT
      nadbavka_absolutnaya.value,
      nadbavka_absolutnaya.values_set_id,
      t1.end_date,
      -1
    FROM industry.nadbavka_absolutnaya
      LEFT JOIN industry.sprav ON sprav.name = 'current_period'
      LEFT JOIN industry.period t1 ON sprav.value = t1.id
      LEFT JOIN industry.period t2 ON sprav.value - 1 = t2.id
    WHERE
      nadbavka_absolutnaya.data BETWEEN t2.begin_date AND t2.end_date;

  /*вставка исходных данных для счет-фактур*/
  INSERT INTO industry.schetfactura_date (
    firm_id, period_id, date,
    edit1, edit2, edit3,
    edit4, edit5, edit6, data_nakl)
    (
      SELECT
        firm.id,
        t1.id,
        t1.end_date,
        t3.edit1,
        t3.edit2,
        t3.edit3,
        t3.edit4,
        t3.edit5,
        t3.edit6,
        t1.end_date
      FROM industry.firm
        LEFT JOIN industry.sprav ON sprav.name = 'current_period'
        LEFT JOIN industry.period t1 ON sprav.value = t1.id
        LEFT JOIN industry.period t2 ON sprav.value - 1 = t2.id
        LEFT JOIN industry.schetfactura_date t3 ON t3.period_id = t2.id AND t3.firm_id = firm.id
    );

  /*симуляция небюджетных организаций в бюджетные для верного расчета пени*/
  INSERT INTO industry.fine_as_budget (firm_id, period_id)
  (
   SELECT 
    firm_id,
    industry.current_period_id()
   FROM industry.fine_as_budget WHERE period_id = (industry.current_period_id()-1)
  );

  RETURN;

END;
$$;

comment on function goto_next_period_fine()
is 'Переход в следующий месяц';

