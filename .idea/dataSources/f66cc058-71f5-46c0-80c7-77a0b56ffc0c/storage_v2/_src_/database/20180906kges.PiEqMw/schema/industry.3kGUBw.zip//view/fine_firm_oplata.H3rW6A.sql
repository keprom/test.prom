create view fine_firm_oplata as
  SELECT firm.id AS firm_id, fine_oplata.value, fine_oplata.data, fine_oplata.nds, payment_number.number, payment_number.name, period.id AS period_id FROM (((industry.firm LEFT JOIN industry.period ON ((1 = 1))) LEFT JOIN industry.fine_oplata ON ((((firm.id = fine_oplata.firm_id) AND (fine_oplata.data >= period.begin_date)) AND (fine_oplata.data <= period.end_date)))) LEFT JOIN industry.payment_number ON ((fine_oplata.payment_number_id = payment_number.id))) WHERE (fine_oplata.value IS NOT NULL) ORDER BY fine_oplata.data;

