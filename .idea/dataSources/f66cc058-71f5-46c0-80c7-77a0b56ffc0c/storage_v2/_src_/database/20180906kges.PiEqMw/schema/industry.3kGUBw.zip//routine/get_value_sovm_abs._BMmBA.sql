create function get_value_sovm_abs(id_bill integer, id_period integer)
  returns numeric
language plpgsql
as $$
DECLARE
c_value NUMERIC;
BEGIN
SELECT SUM(sovm_absolutnyy.value)::NUMERIC(24,2)
FROM industry.sovm_absolutnyy
LEFT JOIN industry.values_set ON values_set.id = sovm_absolutnyy.values_set_id
LEFT JOIN industry.counter ON counter.id = values_set.counter_id
LEFT JOIN industry.billing_point ON billing_point.id = counter.point_id
LEFT JOIN industry.period ON sovm_absolutnyy.data >= period.begin_date AND sovm_absolutnyy.data <= period.end_date
WHERE billing_point.id = id_bill and period.id = id_period
INTO c_value;
 c_value := coalesce(c_value, 0);
RETURN c_value;
END;
$$;

