create view energo_24 as
  SELECT firm_otrasl.id AS firm_otrasl_id, firm_otrasl.name AS firm_otrasl_name, sum(vedomost.itogo_kvt) AS sum, period.id AS period_id FROM (((industry.firm_otrasl LEFT JOIN industry.period ON ((period.id = period.id))) LEFT JOIN industry.firm ON ((firm.otrasl_id = firm_otrasl.id))) LEFT JOIN industry."vedomost-2numround" vedomost ON (((firm.id = vedomost.firm_id) AND (vedomost.period_id = period.id)))) GROUP BY firm_otrasl.id, firm_otrasl.name, period.id ORDER BY firm_otrasl.id;

