create function uroven_tariff_value(_data date, _kvt numeric, OUT _tariff numeric, _tariff_id integer)
  returns numeric
language plpgsql
as $$
declare 
buf_data date;
_period_id integer;
buf_kvt numeric(24,4);
begin
 
select max(data) from industry.tariff_period where data<=_data  and tariff_id=_tariff_id into buf_data;
select id from industry.tariff_period where data=buf_data and tariff_id=_tariff_id into _period_id;
select min(kvt) from industry.tariff_value where tariff_period_id=_period_id and kvt=_kvt into buf_kvt;
select value from industry.tariff_value where tariff_period_id=_period_id and kvt=buf_kvt into _tariff;


end;
$$;

