create view current_firm_oplata as
  SELECT oplata.id, oplata.firm_id, oplata.value, oplata.nds, oplata.data, oplata.payment_number_id, oplata.document_number FROM ((industry.oplata LEFT JOIN industry.period ON (((oplata.data >= period.begin_date) AND (oplata.data <= period.end_date)))) LEFT JOIN industry.sprav ON (((sprav.name)::text = 'current_period'::text))) WHERE ((sprav.value)::integer = period.id);

