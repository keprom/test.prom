create function on_insert_new_firm()
  returns trigger
language plpgsql
as $$
declare 
 _current_period integer;
 _current_period_data date;
begin
select value::integer from industry.sprav where name='current_period' into _current_period;
select end_date from industry.period where id=_current_period into _current_period_data;

    insert into industry.schetfactura_date 
    (firm_id,period_id,date)
    values (NEW.id,_current_period,_current_period_data);
  
    insert into industry.saldo 
    (firm_id,period_id,value)
    values (NEW.id,_current_period,0);

    insert into industry.fine_saldo
    (firm_id, period_id, value)
    values (NEW.id, _current_period, 0);

    insert into industry.fine_firm
    (firm_id, period_id, border_day, is_fine, is_calendar)
    values (NEW.id, _current_period, 20, true, 0);

return NEW;
end;
$$;

