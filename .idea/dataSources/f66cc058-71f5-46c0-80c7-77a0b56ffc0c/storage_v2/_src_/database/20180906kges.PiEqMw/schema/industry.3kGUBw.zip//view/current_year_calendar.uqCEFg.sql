create view current_year_calendar as
  SELECT fine_calendar.day_id, fine_calendar.year, fine_calendar.month, fine_calendar.day, fine_calendar.quarter, fine_calendar.day_of_week, fine_calendar.day_of_year, fine_calendar.week_of_year, fine_calendar.is_off, fine_calendar.month_name FROM (industry.fine_calendar JOIN industry.period ON ((date_part('year'::text, period.begin_date) = (fine_calendar.year)::double precision))) WHERE (period.id = industry.current_period_id()) ORDER BY fine_calendar.day_id;

