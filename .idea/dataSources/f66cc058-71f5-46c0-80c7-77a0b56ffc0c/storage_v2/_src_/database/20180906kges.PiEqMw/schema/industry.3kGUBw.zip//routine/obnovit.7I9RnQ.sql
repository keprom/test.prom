create function obnovit()
  returns void
language plpgsql
as $$
declare 
	buf text;
	buf2 text;
	buf3 integer;
	buf4 integer;
	buf5 integer;
	_firm_id integer;
	_t_uch integer;
	_ts integer;
	_mosh text;
	_time text;
begin


 
 for _firm_id,buf in select id,name from industry.firm loop
	select "KOD_FIR" from ses_copy."IDENT" where "NAIM" = buf into buf4;
	if buf4 is not null then
		for _t_uch in 
		  select t_uch from industry.billing_point where firm_id=_firm_id loop
			select "MOSH","TIM" from ses_copy."T_UCH" where "KOD_FIR"=buf4 and "T_UCH"=_t_uch
			  into _mosh,_time;
			update industry.billing_point set 
				power=_mosh,time_in_day=_time where firm_id=_firm_id and t_uch=_t_uch;
			
		end loop;
	end if;
 end loop;
end;
$$;

