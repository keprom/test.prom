create function current_period_id()
  returns integer
language plpgsql
as $$
declare period_id integer;
begin
 select period.id from industry.period
 left join industry.sprav on period.id=sprav.value::integer
 where sprav.name='current_period' into period_id;

 return period_id;
end;
$$;

