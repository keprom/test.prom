create view nadbavka as
  SELECT nadbavka_absolutnaya.id, nadbavka_absolutnaya.value, values_set.counter_id, period.id AS period_id, nadbavka_absolutnaya.tariff_value, nadbavka_absolutnaya.data FROM ((industry.nadbavka_absolutnaya LEFT JOIN industry.values_set ON ((nadbavka_absolutnaya.values_set_id = values_set.id))) LEFT JOIN industry.period ON (((nadbavka_absolutnaya.data >= period.begin_date) AND (nadbavka_absolutnaya.data <= period.end_date))));

