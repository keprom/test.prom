create view fine_oplata_edit as
  SELECT fine_oplata.id, fine_oplata.data, fine_oplata.value, fine_oplata.document_number, firm.dogovor, payment_number.number FROM ((industry.fine_oplata LEFT JOIN industry.firm ON ((fine_oplata.firm_id = firm.id))) LEFT JOIN industry.payment_number ON ((payment_number.id = fine_oplata.payment_number_id))) ORDER BY fine_oplata.data;

