create function is_budget_firm(id_firm integer, id_period integer)
  returns integer
language plpgsql
as $$
--выясняем является ли организация бюджетной или ей подобной (жылу, су)
  DECLARE is_budget INTEGER;
  BEGIN
  SELECT 
	CASE
            WHEN firm_group.name::text ~~ '%Бюджет%'::text OR fine_as_budget.firm_id IS NOT NULL THEN 1
            ELSE 0
        END AS is_budget
  FROM industry.firm_group
  JOIN industry.firm_subgroup ON firm_subgroup.group_id = firm_group.id
  JOIN industry.firm ON firm.subgroup_id = firm_subgroup.id
  LEFT JOIN industry.fine_as_budget ON fine_as_budget.firm_id = firm.id AND fine_as_budget.period_id = id_period
  WHERE firm.id = id_firm
  INTO is_budget;

  RETURN is_budget;
  
  END;
$$;

