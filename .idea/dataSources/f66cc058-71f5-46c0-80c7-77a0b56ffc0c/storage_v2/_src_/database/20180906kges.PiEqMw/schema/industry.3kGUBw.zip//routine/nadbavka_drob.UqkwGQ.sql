create function nadbavka_drob(_value numeric, _values_set_id integer, _data date, _tariff_value numeric, _ost numeric, _uroven integer, OUT ind boolean)
  returns boolean
language plpgsql
as $$
declare
tar numeric(24,4);
_person integer;
_sum_kvt numeric(24,4);
_uroven_last integer;
_firm integer;
_start_data date;
_end_data date;
begin
ind = false;

select begin_date, end_date from industry.period
	where id = (select "value" from industry.sprav where "name" = 'current_period')
	into _start_data, _end_data;

select firm.person, firm.id from industry.firm
left join industry.billing_point on billing_point.firm_id = firm.id
left join industry.counter on counter.point_id = billing_point.id
left join industry.values_set on values_set.counter_id = counter.id
where values_set.id = _values_set_id
into _person, _firm;

select sum(nadbavka_absolutnaya.value), nadbavka_absolutnaya.uroven
	from industry.nadbavka_absolutnaya
	left join industry.values_set on values_set.id = nadbavka_absolutnaya.values_set_id
	left join industry.counter on counter.id = values_set.counter_id
	left join industry.billing_point on billing_point.id = counter.point_id
	left join industry.firm on firm.id = billing_point.firm_id
	where firm.id = _firm 
		and values_set.tariff_id = 12
		and nadbavka_absolutnaya.data >= _start_data
		and nadbavka_absolutnaya.data <= _end_data
		and nadbavka_absolutnaya.uroven = (select max(uroven)
						from industry.nadbavka_absolutnaya
							left join industry.values_set on values_set.id = nadbavka_absolutnaya.values_set_id
							left join industry.counter on counter.id = values_set.counter_id
							left join industry.billing_point on billing_point.id = counter.point_id
							left join industry.firm on firm.id = billing_point.firm_id
							where firm.id = _firm 
								and values_set.tariff_id = 12
								and nadbavka_absolutnaya.data >= _start_data
								and nadbavka_absolutnaya.data <= _end_data)
group by nadbavka_absolutnaya.uroven
into _sum_kvt, _uroven_last;



if (_uroven=0) then 


	if (_uroven_last is null) then

		if (_value <= 100*_person)  then
			tar = industry.uroven_tariff_value(_data,100,12);
			_ost = 100*_person - _value;
			insert into industry.nadbavka_absolutnaya ("value", "values_set_id", "data", "tariff_value", "ost", "uroven") values (_value, _values_set_id, _data, tar, _ost, 1);
			ind = true;
		end if;

		if (_value > 100*_person) and (_value <= 190*_person) then
			tar = industry.uroven_tariff_value(_data,100,12);
			insert into industry.nadbavka_absolutnaya ("value", "values_set_id", "data", "tariff_value", "ost", "uroven") 
			values (100*_person, _values_set_id, _data, tar, 0, 1);	

			tar = industry.uroven_tariff_value(_data,90,12);
			_value = _value - 100*_person;
			_ost = 90*_person-_value;
			insert into industry.nadbavka_absolutnaya ("value", "values_set_id", "data", "tariff_value", "ost", "uroven") values (_value, _values_set_id, _data, tar, _ost, 2);
			ind = true;
		end if;

		if (_value > 190*_person) then
			tar = industry.uroven_tariff_value(_data,100,12);
			insert into industry.nadbavka_absolutnaya ("value", "values_set_id", "data", "tariff_value", "ost", "uroven") values (100*_person, _values_set_id, _data, tar, 0, 1);	
	
			tar = industry.uroven_tariff_value(_data,90,12);
			insert into industry.nadbavka_absolutnaya ("value", "values_set_id", "data", "tariff_value", "ost", "uroven") values (90*_person, _values_set_id, _data, tar, 0, 2);

			tar = industry.uroven_tariff_value(_data,200,12);
			_value = _value - 190*_person;
			insert into industry.nadbavka_absolutnaya ("value", "values_set_id", "data", "tariff_value", "ost", "uroven") values (_value, _values_set_id, _data, tar, 0, 3);
			ind = true;
		end if;


	else

		if (_uroven_last = 1) then
 
			if (_value+_sum_kvt <= 100*_person)  then
				tar = industry.uroven_tariff_value(_data,100,12);
				_ost = 100*_person - _value;
				insert into industry.nadbavka_absolutnaya ("value", "values_set_id", "data", "tariff_value", "ost", "uroven") 
				values (_value, _values_set_id, _data, tar, _ost, 1);
				ind = true;
			end if;

			if (_value+_sum_kvt > 100*_person) and (_value+_sum_kvt <= 190*_person) then
				tar = industry.uroven_tariff_value(_data,100,12);
				insert into industry.nadbavka_absolutnaya ("value", "values_set_id", "data", "tariff_value", "ost", "uroven") 
				values (100*_person-_sum_kvt, _values_set_id, _data, tar, 0, 1);	

				tar = industry.uroven_tariff_value(_data,90,12);
				_value = _value - 100*_person+_sum_kvt;
				_ost = 90*_person-_value;
				insert into industry.nadbavka_absolutnaya ("value", "values_set_id", "data", "tariff_value", "ost", "uroven") 
				values (_value, _values_set_id, _data, tar, _ost, 2);
				ind = true;
			end if;

			if (_value+_sum_kvt > 190*_person) then
				tar = industry.uroven_tariff_value(_data,100,12);
				insert into industry.nadbavka_absolutnaya ("value", "values_set_id", "data", "tariff_value", "ost", "uroven") 
				values (100*_person-_sum_kvt, _values_set_id, _data, tar, 0, 1);	

				tar = industry.uroven_tariff_value(_data,90,12);
				insert into industry.nadbavka_absolutnaya ("value", "values_set_id", "data", "tariff_value", "ost", "uroven") 
				values (90*_person, _values_set_id, _data, tar, 0, 2);

				tar = industry.uroven_tariff_value(_data,200,12);
				_value = _value - 190*_person+_sum_kvt;
				insert into industry.nadbavka_absolutnaya ("value", "values_set_id", "data", "tariff_value", "ost", "uroven") 
				values (_value, _values_set_id, _data, tar, 0, 3);
				ind = true;
			end if;
		end if;

		if (_uroven_last = 2) then

			if (_value+_sum_kvt <= 90*_person)  then
				tar = industry.uroven_tariff_value(_data,90,12);
				_ost = 90*_person - _value+_sum_kvt;
				insert into industry.nadbavka_absolutnaya ("value", "values_set_id", "data", "tariff_value", "ost", "uroven") 
				values (_value, _values_set_id, _data, tar, _ost, 2);
				ind = true;
			end if;

			if (_value+_sum_kvt > 90*_person) then
				tar = industry.uroven_tariff_value(_data,90,12);
				insert into industry.nadbavka_absolutnaya ("value", "values_set_id", "data", "tariff_value", "ost", "uroven") 
				values (90*_person-_sum_kvt, _values_set_id, _data, tar, 0, 2);	

				tar = industry.uroven_tariff_value(_data,200,12);
				_value = _value - 90*_person+_sum_kvt;
				insert into industry.nadbavka_absolutnaya ("value", "values_set_id", "data", "tariff_value", "ost", "uroven") 
				values (_value, _values_set_id, _data, tar, 0, 3);
				ind = true;
			end if;
		end if;

		if (_uroven_last = 3) then

			tar = industry.uroven_tariff_value(_data,200,12);
			insert into industry.nadbavka_absolutnaya ("value", "values_set_id", "data", "tariff_value", "ost", "uroven") 
			values (_value, _values_set_id, _data, tar, _ost, 3);
			ind = true;
		end if;



	end if;
end if;
end;
$$;

