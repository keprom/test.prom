create view obwii as
  SELECT only_obwii.id, tariff_value.value, only_obwii.data, period.id AS period_id FROM ((industry.only_obwii LEFT JOIN industry.tariff_value ON ((only_obwii.id = tariff_value.tariff_period_id))) LEFT JOIN industry.period ON (((only_obwii.data >= period.begin_date) AND (only_obwii.data <= period.end_date))));

