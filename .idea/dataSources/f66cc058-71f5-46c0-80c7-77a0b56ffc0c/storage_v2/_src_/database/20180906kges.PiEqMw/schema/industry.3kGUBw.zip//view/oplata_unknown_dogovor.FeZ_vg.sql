create view oplata_unknown_dogovor as
  SELECT DISTINCT oplata_buf.dog FROM industry.oplata_buf WHERE (NOT (oplata_buf.dog IN (SELECT firm.dogovor FROM industry.firm))) ORDER BY oplata_buf.dog;

