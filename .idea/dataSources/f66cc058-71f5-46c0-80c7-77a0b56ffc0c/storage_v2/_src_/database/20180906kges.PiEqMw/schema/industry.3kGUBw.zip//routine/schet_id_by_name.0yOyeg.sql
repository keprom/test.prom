create function schet_id_by_name(_name text)
  returns integer
language plpgsql
as $$
declare i integer;
begin
  select id from industry.payment_number where trim(number)=trim(_name) into i;
  return i;
end;
$$;

