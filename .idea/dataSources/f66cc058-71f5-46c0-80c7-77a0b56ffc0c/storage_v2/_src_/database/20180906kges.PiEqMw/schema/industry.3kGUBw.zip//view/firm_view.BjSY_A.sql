create view firm_view as
  SELECT firm.id, firm.name, firm.firm_closed, firm.dogovor, firm.rnn, firm.director_name, firm.dogovor_date, firm.subgroup_id, firm.address, firm.bank_id, firm.telefon, firm.director_address, firm.raschetnyy_schet, firm.otrasl_id, firm.firm_power_group_id, firm.ture_id, firm.user_id, ture.name AS ture_name, firm.close_type FROM (industry.firm LEFT JOIN industry.ture ON ((firm.ture_id = ture.id)));

