create view asd as
  SELECT "Tolyanba".firm_dog, firm.name AS firm_name, curent_vedomost.firm_id, curent_vedomost.itogo_with_nds AS nach, curent_vedomost.saldo_value AS saldo_nach, (curent_vedomost.itogo_with_nds + curent_vedomost.saldo_value) AS saldo_konec, curent_vedomost.period_id AS period FROM ((industry.curent_vedomost LEFT JOIN industry."Tolyanba" ON ((curent_vedomost.firm_id = curent_vedomost.firm_id))) LEFT JOIN industry.firm ON ((curent_vedomost.firm_id = firm.id))) WHERE ((firm.dogovor > 0) AND (firm.dogovor < 50));

