create function get_nach(id_firm integer, id_period integer)
  returns numeric
language plpgsql
as $$
DECLARE
is_b INTEGER;
nach NUMERIC;

BEGIN

SELECT *
FROM industry.is_budget_firm(id_firm, id_period)
INTO is_b;

IF is_b = 1 THEN 
  BEGIN 
    SELECT firm_itog_vedomost.itogo_with_nds
    FROM industry.firm_itog_vedomost
    WHERE firm_itog_vedomost.firm_id = id_firm AND firm_itog_vedomost.period_id = (id_period-1)
    INTO nach;
  END;
ELSE 
  BEGIN 
    SELECT firm_itog_vedomost.itogo_with_nds
    FROM industry.firm_itog_vedomost
    WHERE firm_itog_vedomost.firm_id = id_firm AND firm_itog_vedomost.period_id = id_period
    INTO nach;  
  END;
END IF;

RETURN nach;

END;
$$;

