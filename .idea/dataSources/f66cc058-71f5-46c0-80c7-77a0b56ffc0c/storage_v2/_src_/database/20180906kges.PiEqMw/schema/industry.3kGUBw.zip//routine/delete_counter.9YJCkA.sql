create function delete_counter(_counter_id integer)
  returns integer
language plpgsql
as $$
declare _vs_id integer;
     count_values integer;
begin 

select count(*) from industry.not_current_counter_value where counter_id=_counter_id into count_values;
if count_values>0 then return 1; end if;
alter table industry.counter_value disable trigger all;
select id from industry.values_set where counter_id=_counter_id into _vs_id;
delete from industry.counter_value where values_set_id=_vs_id;
delete from industry.values_set where id=_vs_id;
delete from industry.counter where id=_counter_id;
alter table industry.counter_value enable trigger all;
return -1;
end;
$$;

