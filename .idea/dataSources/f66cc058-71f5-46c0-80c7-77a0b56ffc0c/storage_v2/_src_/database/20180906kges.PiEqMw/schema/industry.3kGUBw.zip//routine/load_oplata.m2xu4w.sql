create function load_oplata()
  returns void
language plpgsql
as $$
DECLARE 
buf_row RECORD;
day_fine_opl NUMERIC;
day_opl NUMERIC;
opl_dif NUMERIC;
buf_fsv NUMERIC;
BEGIN

/*очистка таблицы для временного хранения сальдо пени*/
DELETE FROM industry.fine_flop;

/*заполнение временной таблицы*/
INSERT INTO industry.fine_flop (firm_id, fine_saldo_value)
SELECT 
  firm_id,
  value
FROM industry.fine_saldo WHERE period_id = industry.current_period_id();

/*очистка таблицы оплаты начислений*/
DELETE FROM industry.oplata
WHERE data BETWEEN
(SELECT period.begin_date FROM industry.period WHERE period.id = industry.current_period_id())
AND 
(SELECT period.end_date FROM industry.period WHERE period.id = industry.current_period_id());

/*очистка таблицы оплаты пени*/
DELETE FROM industry.fine_oplata
WHERE data BETWEEN
(SELECT period.begin_date FROM industry.period WHERE period.id = industry.current_period_id())
AND 
(SELECT period.end_date FROM industry.period WHERE period.id = industry.current_period_id());

/*проход по загруженным оплатам и рассортировка их по таблицам*/
FOR buf_row IN
  SELECT
    industry.firm_id_by_dogovor(dog) AS firm_id,
    data as oplata_data,
    n_dokum,
    industry.schet_id_by_name(schet) as schet_id,
    sum as sum_with_nds,
    sum / (1 + (industry.current_nds() / 100)) as sum_bez_nds,
    industry.current_nds() as nds
  FROM industry.oplata_buf
  WHERE industry.firm_id_by_dogovor(dog) IS NOT NULL AND industry.schet_id_by_name(schet) IS NOT NULL
LOOP

  SELECT fine_saldo_value 
  FROM industry.fine_flop
  WHERE firm_id = buf_row.firm_id
  INTO buf_fsv;

  opl_dif := buf_fsv - buf_row.sum_with_nds;
  day_fine_opl := 0;
  day_opl := 0;
  
  IF (opl_dif >= 0) THEN 
    BEGIN
     day_fine_opl := buf_row.sum_bez_nds;
     day_opl := 0;
    END;
  END IF;
  
  IF (opl_dif < 0) THEN 
    BEGIN
     day_fine_opl :=  buf_fsv / (1 + (industry.current_nds() / 100));
     day_opl := buf_row.sum_bez_nds - day_fine_opl;
     opl_dif := 0;
    END;
  END IF;

  IF (day_opl > 0) THEN 
    BEGIN
      INSERT INTO industry.oplata (firm_id,data,document_number,payment_number_id,value,nds)
      VALUES (buf_row.firm_id, buf_row.oplata_data, buf_row.n_dokum, buf_row.schet_id, day_opl, industry.current_nds());
    END;
  END IF;

  IF (day_fine_opl > 0) THEN 
    BEGIN
      INSERT INTO industry.fine_oplata (firm_id,data,document_number,payment_number_id,value,nds)
      VALUES (buf_row.firm_id, buf_row.oplata_data, buf_row.n_dokum, buf_row.schet_id, day_fine_opl, industry.current_nds());
    END;
  END IF;

  UPDATE industry.fine_flop 
  SET fine_saldo_value = opl_dif
  WHERE firm_id = buf_row.firm_id;
  
END LOOP;

/*очистка таблицы для временного хранения сальдо пени*/
DELETE FROM industry.fine_flop;

END;
$$;

