create view firmid_by_values_set as
  SELECT billing_point.firm_id, values_set.id AS values_set_id FROM ((industry.billing_point LEFT JOIN industry.counter ON ((billing_point.id = counter.point_id))) LEFT JOIN industry.values_set ON ((values_set.counter_id = counter.id)));

