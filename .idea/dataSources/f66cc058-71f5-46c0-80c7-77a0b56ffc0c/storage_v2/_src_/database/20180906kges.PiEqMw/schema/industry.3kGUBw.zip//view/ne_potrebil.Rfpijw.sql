create view ne_potrebil as
  SELECT "7-re".period_id, firm.name AS firm_name, firm.dogovor, firm.user_id, "user".name AS user_name FROM ((industry."7-re" LEFT JOIN industry.firm ON (("7-re".firm_id = firm.id))) LEFT JOIN industry."user" ON ((firm.user_id = "user".id))) WHERE ("7-re".nachisleno = (0)::numeric) ORDER BY firm.dogovor;

